/-
  Divisor/ExtractorBridge.lean

  T4 extractor bridge theorems (D3, D4, D5 of the axiom elimination plan).

  These theorems take σ-matching-style hypotheses (distilled from the
  output of `log_deriv_nonvanishing_criterion`) and produce the
  extractor's conclusions (`extractorSucceeds` and the group-law
  equation `target = Σ [scalars_i] · bases_i`). The upstream bridge
  `logDerivCheckFn ≡ 0 on E × E ⇒ σ-matching exists` (plan's D1+D2)
  is future work; this file provides the extractor-side combinatorics
  that consume a σ-matching when it becomes available.

  Structure:
  * `extractorSucceeds_of_natural_witness` (D3): given a natural-number
    witness `coeff : Fin msg.k → ℕ` whose ZMod image matches
    `-groupSum` at canonical indices (and is 0 elsewhere) with
    `coeff i < d`, the extractor succeeds at bound `d` and
    `extractedScalars i = coeff i` (as ℤ).
  * `target_eq_weightedSum_of_zero_sum` (D5): from the principality-
    derived equation `(-P) + Σ [extractedScalars i] · B_i = 0`,
    conclude `target = Σ [extractedScalars i] · B_i`.
-/
import Divisor.Soundness
import Divisor.DivisorPrincipal
import Divisor.PolyFibK

namespace Divisor

open Finset Classical

variable (E : ECSetup)

/-! ## D4: extractor's divisor principality ⇒ zero-sum

The extractor's divisor (as a coefficient function on `ECPoint E.q`)
equals `+1` at `-P`, `extractedScalars i` at each base point
`B_i` (aggregating duplicates), and `-D.degE` at `∞`. Mirror of
`honestDivisorCoeffs` with `extractedScalars` in place of `wit.scalars`.
-/

/-- Extractor-side divisor coefficient function. -/
noncomputable def extractorDivisorCoeffs
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) : ECPoint E.q → ℤ :=
  fun P => match P with
    | .infinity => -(msg.toD.degE : ℤ)
    | .affine x y =>
        (if (x, y) = (stmt.target.1, -stmt.target.2) then 1 else 0) +
        ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
          (fun j => extractorBases E stmt msg hkm j = (x, y)),
          extractedScalars E stmt msg hkm j

/-- Candidate finite superset of the support: `{∞, -P, all base points}`. -/
noncomputable def extractorDivisorCandidate
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) : Finset (ECPoint E.q) :=
  insert (ECPoint.infinity : ECPoint E.q)
    (insert (ECPoint.affine stmt.target.1 (-stmt.target.2))
      ((Finset.univ : Finset (Fin msg.k)).image
        (fun j => ECPoint.affine (extractorBases E stmt msg hkm j).1
                                 (extractorBases E stmt msg hkm j).2)))

/-- Value of `extractorDivisorCoeffs` at `∞`. -/
theorem extractorDivisorCoeffs_infinity
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    extractorDivisorCoeffs E stmt msg hkm ECPoint.infinity =
      -(msg.toD.degE : ℤ) := rfl

/-- Value of `extractorDivisorCoeffs` at `-P` (general case). -/
theorem extractorDivisorCoeffs_negP
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty) :
    extractorDivisorCoeffs E stmt msg hkm
        (ECPoint.affine stmt.target.1 (-stmt.target.2)) = 1 := by
  classical
  show (if (stmt.target.1, -stmt.target.2) = (stmt.target.1, -stmt.target.2)
        then (1 : ℤ) else 0) +
       ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
         (fun j => extractorBases E stmt msg hkm j =
                    (stmt.target.1, -stmt.target.2)),
         extractedScalars E stmt msg hkm j = 1
  rw [if_pos rfl]
  have hEmpty : ((Finset.univ : Finset (Fin msg.k)).filter
      (fun j => extractorBases E stmt msg hkm j =
                 (stmt.target.1, -stmt.target.2))) = ∅ := by
    rw [Finset.eq_empty_iff_forall_notMem]
    intro j hj
    apply hNoNegP
    exact ⟨j, hj⟩
  rw [hEmpty, Finset.sum_empty, add_zero]

/-- The filter set at position `i`'s base point equals the extractor
    group of `i`. -/
theorem filter_bases_eq_extractorGroup
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i : Fin msg.k) :
    ((Finset.univ : Finset (Fin msg.k)).filter
      (fun j => extractorBases E stmt msg hkm j =
                 extractorBases E stmt msg hkm i)) =
    extractorGroup E stmt msg hkm i := by rfl

/-- Under general case, a non-canonical index has `extractedScalars = 0`. -/
theorem extractedScalars_zero_of_notCanonical
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (i : Fin msg.k) (hNotCanon : ¬ extractorIsCanonical E stmt msg hkm i) :
    extractedScalars E stmt msg hkm i = 0 := by
  show (if hne : (negPIndexSet E stmt msg hkm).Nonempty
        then (if i = (negPIndexSet E stmt msg hkm).min' hne
              then (-1 : ℤ) else 0)
        else if extractorIsCanonical E stmt msg hkm i
             then ((extractorGroupSum E stmt msg hkm i).val : ℤ)
             else 0) = 0
  rw [dif_neg hNoNegP, if_neg hNotCanon]

/-- Within an extractor group, only the canonical (minimum-index)
    element has nonzero `extractedScalars` under the general case. -/
theorem extractedScalars_group_canonical
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i j : Fin msg.k) (hj : j ∈ extractorGroup E stmt msg hkm i) :
    extractorGroup E stmt msg hkm j = extractorGroup E stmt msg hkm i := by
  classical
  ext x
  simp only [extractorGroup, Finset.mem_filter, Finset.mem_univ, true_and]
  have hji : extractorBases E stmt msg hkm j = extractorBases E stmt msg hkm i := by
    have := Finset.mem_filter.mp hj
    exact this.2
  constructor
  · intro hx; rw [hji] at hx; exact hx
  · intro hx; rw [hji]; exact hx

/-- Sum of `extractedScalars` over an extractor group equals the value at
    the canonical (min-index) position. -/
theorem sum_extractedScalars_over_group
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (i : Fin msg.k) :
    ∑ j ∈ extractorGroup E stmt msg hkm i,
      extractedScalars E stmt msg hkm j
    = extractedScalars E stmt msg hkm
        ((extractorGroup E stmt msg hkm i).min'
          (extractorGroup_nonempty E stmt msg hkm i)) := by
  classical
  set c := (extractorGroup E stmt msg hkm i).min'
    (extractorGroup_nonempty E stmt msg hkm i)
  apply Finset.sum_eq_single c
  · intro j hj hjc
    have hGj : extractorGroup E stmt msg hkm j = extractorGroup E stmt msg hkm i :=
      extractedScalars_group_canonical E stmt msg hkm i j hj
    have hNotCanon : ¬ extractorIsCanonical E stmt msg hkm j := by
      intro hCanon
      have hmin_j : (extractorGroup E stmt msg hkm j).min'
                      (extractorGroup_nonempty E stmt msg hkm j) = j := hCanon
      have hj_lb : ∀ y ∈ extractorGroup E stmt msg hkm i, j ≤ y := by
        intro y hy
        rw [← hGj] at hy
        rw [← hmin_j]
        exact Finset.min'_le _ y hy
      have hc_le_j : c ≤ j := Finset.min'_le _ j hj
      have hj_le_c : j ≤ c := hj_lb c (Finset.min'_mem _ _)
      exact hjc (le_antisymm hj_le_c hc_le_j)
    exact extractedScalars_zero_of_notCanonical E stmt msg hkm hNoNegP j hNotCanon
  · intro hnotin
    exact absurd (Finset.min'_mem _ _) hnotin

/-- Canonical-index Finset: all `i : Fin msg.k` that are the minimum
    (= canonical) index in their base-point group. -/
noncomputable def canonicalFinset
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    Finset (Fin msg.k) :=
  (Finset.univ : Finset (Fin msg.k)).filter (extractorIsCanonical E stmt msg hkm)

/-- `ECPoint.affine (extractorBases j)` as a function `Fin msg.k → ECPoint E.q`. -/
noncomputable def basesAffineEC
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (j : Fin msg.k) : ECPoint E.q :=
  ECPoint.affine (extractorBases E stmt msg hkm j).1
                 (extractorBases E stmt msg hkm j).2

/-- Injectivity of `basesAffineEC` on the canonical Finset: two canonical
    indices with the same affine base point are equal (they're both the
    min of the same group). -/
theorem basesAffineEC_injOn_canonical
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    ∀ j₁ ∈ canonicalFinset E stmt msg hkm,
    ∀ j₂ ∈ canonicalFinset E stmt msg hkm,
    basesAffineEC E stmt msg hkm j₁ = basesAffineEC E stmt msg hkm j₂ →
    j₁ = j₂ := by
  classical
  intro j₁ hj₁ j₂ hj₂ heq
  simp only [canonicalFinset, Finset.mem_filter, Finset.mem_univ, true_and] at hj₁ hj₂
  -- From heq: extractorBases j₁ = extractorBases j₂ (after pair destructuring).
  have hb : extractorBases E stmt msg hkm j₁ = extractorBases E stmt msg hkm j₂ := by
    simp only [basesAffineEC] at heq
    have h12 := ECPoint.affine.injEq .. |>.mp heq
    exact Prod.ext h12.1 h12.2
  -- hb means j₁ ∈ extractorGroup j₂ and vice versa.
  have hj₁inG : j₁ ∈ extractorGroup E stmt msg hkm j₂ := by
    simp only [extractorGroup, Finset.mem_filter, Finset.mem_univ, true_and]
    exact hb
  have hG_eq : extractorGroup E stmt msg hkm j₁ = extractorGroup E stmt msg hkm j₂ :=
    extractedScalars_group_canonical E stmt msg hkm j₂ j₁ hj₁inG
  -- Both j₁, j₂ are canonicals of this common group.
  -- From hj₁: (extractorGroup j₁).min' _ = j₁.
  -- From hj₂: (extractorGroup j₂).min' _ = j₂.
  -- Using hG_eq: (extractorGroup j₂).min' _ = j₁ (from hj₁ after rewriting).
  -- And = j₂ (from hj₂). So j₁ = j₂.
  have h_min_eq_j₁ : (extractorGroup E stmt msg hkm j₂).min'
      (extractorGroup_nonempty E stmt msg hkm j₂) = j₁ := by
    have hmin : (extractorGroup E stmt msg hkm j₁).min'
        (extractorGroup_nonempty E stmt msg hkm j₁) = j₁ := hj₁
    -- Show j₁ is the min of extractorGroup j₂ by antisymmetry of le.
    apply le_antisymm
    · -- min of j₂'s group ≤ j₁
      apply Finset.min'_le _ _ hj₁inG
    · -- j₁ ≤ min of j₂'s group
      rw [← hmin]
      apply Finset.min'_le _ _
      -- Need min of j₂'s group ∈ extractorGroup j₁.
      rw [hG_eq]
      exact Finset.min'_mem _ _
  -- Now combine with hj₂.
  rw [← h_min_eq_j₁, hj₂]

/-- `canonicalFinset.image basesAffineEC = univ.image basesAffineEC`.
    (Every affine base point is reached by a canonical index.) -/
theorem canonicalFinset_image_eq_univ_image
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    (canonicalFinset E stmt msg hkm).image (basesAffineEC E stmt msg hkm) =
    (Finset.univ : Finset (Fin msg.k)).image (basesAffineEC E stmt msg hkm) := by
  classical
  apply Finset.Subset.antisymm
  · exact Finset.image_subset_image (by
      intro x _; exact Finset.mem_univ x)
  · intro P hP
    simp only [Finset.mem_image, Finset.mem_univ, true_and] at hP
    obtain ⟨j, rfl⟩ := hP
    -- Take the canonical of j's group.
    set j_canon := (extractorGroup E stmt msg hkm j).min'
      (extractorGroup_nonempty E stmt msg hkm j) with hjc
    have hj_canon_in : j_canon ∈ extractorGroup E stmt msg hkm j :=
      Finset.min'_mem _ _
    have hj_canon_is : extractorBases E stmt msg hkm j_canon =
                       extractorBases E stmt msg hkm j := by
      have := Finset.mem_filter.mp hj_canon_in
      exact this.2
    -- j_canon is canonical by def (= min' of its own group, which equals j's group).
    have hj_canon_canon : extractorIsCanonical E stmt msg hkm j_canon := by
      show (extractorGroup E stmt msg hkm j_canon).min'
        (extractorGroup_nonempty E stmt msg hkm j_canon) = j_canon
      have hG_eq : extractorGroup E stmt msg hkm j_canon =
                   extractorGroup E stmt msg hkm j :=
        extractedScalars_group_canonical E stmt msg hkm j j_canon hj_canon_in
      apply le_antisymm
      · apply Finset.min'_le
        exact mem_extractorGroup_self E stmt msg hkm j_canon
      · apply Finset.le_min'
        intro y hy
        rw [hG_eq] at hy
        rw [hjc]
        exact Finset.min'_le _ _ hy
    refine Finset.mem_image.mpr ⟨j_canon, ?_, ?_⟩
    · simp only [canonicalFinset, Finset.mem_filter, Finset.mem_univ, true_and]
      exact hj_canon_canon
    · simp only [basesAffineEC, hj_canon_is]

/-- Zero contribution at non-canonical indices:
    `zsmul (extractedScalars j) (basesAffineEC j) = 0`. -/
theorem zsmul_extractedScalars_basesAffineEC_zero_of_notCanonical
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (j : Fin msg.k) (hNotCanon : ¬ extractorIsCanonical E stmt msg hkm j) :
    ECPoint.zsmul E (extractedScalars E stmt msg hkm j)
      (basesAffineEC E stmt msg hkm j) = 0 := by
  rw [extractedScalars_zero_of_notCanonical E stmt msg hkm hNoNegP j hNotCanon]
  rfl

/-- `extractorDivisorCoeffs` at an affine base point equals
    `extractedScalars` at the canonical representative of that group. -/
theorem extractorDivisorCoeffs_affine_bases
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (i : Fin msg.k) :
    extractorDivisorCoeffs E stmt msg hkm
        (ECPoint.affine (extractorBases E stmt msg hkm i).1
                        (extractorBases E stmt msg hkm i).2) =
      extractedScalars E stmt msg hkm
        ((extractorGroup E stmt msg hkm i).min'
          (extractorGroup_nonempty E stmt msg hkm i)) := by
  classical
  show (if ((extractorBases E stmt msg hkm i).1,
           (extractorBases E stmt msg hkm i).2) =
          (stmt.target.1, -stmt.target.2)
        then (1 : ℤ) else 0) +
       ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
         (fun j => extractorBases E stmt msg hkm j =
                    ((extractorBases E stmt msg hkm i).1,
                     (extractorBases E stmt msg hkm i).2)),
         extractedScalars E stmt msg hkm j = _
  have hNot : ((extractorBases E stmt msg hkm i).1,
               (extractorBases E stmt msg hkm i).2) ≠
              (stmt.target.1, -stmt.target.2) := by
    intro heq
    apply hNoNegP
    refine ⟨i, ?_⟩
    simp only [negPIndexSet, Finset.mem_filter, Finset.mem_univ, true_and]
    have : extractorBases E stmt msg hkm i =
           ((extractorBases E stmt msg hkm i).1,
            (extractorBases E stmt msg hkm i).2) := by
      rcases extractorBases E stmt msg hkm i with ⟨a, b⟩
      rfl
    rw [this, heq]
  rw [if_neg hNot, zero_add]
  have hPair_eq_full :
      ((extractorBases E stmt msg hkm i).1,
       (extractorBases E stmt msg hkm i).2) =
      extractorBases E stmt msg hkm i := by
    rcases extractorBases E stmt msg hkm i with ⟨a, b⟩; rfl
  rw [hPair_eq_full]
  rw [filter_bases_eq_extractorGroup]
  exact sum_extractedScalars_over_group E stmt msg hkm hNoNegP i

/-- For canonical `j`, `extractorDivisorCoeffs (basesAffineEC j) = extractedScalars j`. -/
theorem extractorDivisorCoeffs_basesAffineEC_of_canonical
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (j : Fin msg.k) (hCanon : extractorIsCanonical E stmt msg hkm j) :
    extractorDivisorCoeffs E stmt msg hkm (basesAffineEC E stmt msg hkm j) =
      extractedScalars E stmt msg hkm j := by
  unfold basesAffineEC
  have h1 := extractorDivisorCoeffs_affine_bases E stmt msg hkm hNoNegP j
  have hmin_j : (extractorGroup E stmt msg hkm j).min'
                  (extractorGroup_nonempty E stmt msg hkm j) = j := hCanon
  rw [h1, hmin_j]

/-- Image-reindexing: weightedSum over `univ.image basesAffineEC` of
    `zsmul coeffs ·` equals weightedSum over `univ` of
    `zsmul extractedScalars (basesAffineEC ·)`.

    Goes via: (a) rewrite `univ.image = canonical.image`, (b) apply
    `fold_image` with injectivity on canonical, (c) rewrite the summand
    using `extractorDivisorCoeffs_basesAffineEC_of_canonical`, (d)
    zero-pad from canonical to univ. -/
theorem weightedSum_imageBases_eq_univ_zsmul_extractedScalars
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty) :
    ECPoint.weightedSum E
      ((Finset.univ : Finset (Fin msg.k)).image (basesAffineEC E stmt msg hkm))
      (fun P => ECPoint.zsmul E (extractorDivisorCoeffs E stmt msg hkm P) P)
    = ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
      (fun j => ECPoint.zsmul E (extractedScalars E stmt msg hkm j)
        (basesAffineEC E stmt msg hkm j)) := by
  classical
  set bEC := basesAffineEC E stmt msg hkm with hbEC_def
  set c := extractorDivisorCoeffs E stmt msg hkm with hc_def
  set canFs := canonicalFinset E stmt msg hkm with hcanFs_def
  -- Step A: rewrite `univ.image = canonical.image`.
  rw [show (Finset.univ : Finset (Fin msg.k)).image bEC = canFs.image bEC from
        (canonicalFinset_image_eq_univ_image E stmt msg hkm).symm]
  -- Step B: fold_image with injectivity on canonical.
  have hInj : ∀ x ∈ canFs, ∀ y ∈ canFs, bEC x = bEC y → x = y :=
    basesAffineEC_injOn_canonical E stmt msg hkm
  have hInjOn : Set.InjOn bEC canFs := fun x hx y hy h => hInj x hx y hy h
  show (canFs.image bEC).fold (ECPoint.add E) 0
        (fun P => ECPoint.zsmul E (c P) P) = _
  rw [Finset.fold_image hInjOn]
  -- After fold_image: canFs.fold (ECPoint.add E) 0 ((fun P => zsmul (c P) P) ∘ bEC).
  -- Step C: rewrite summand at canonical positions.
  have hFoldCongr :
      canFs.fold (ECPoint.add E) 0
        ((fun P => ECPoint.zsmul E (c P) P) ∘ bEC)
      = canFs.fold (ECPoint.add E) 0
        (fun j => ECPoint.zsmul E (extractedScalars E stmt msg hkm j) (bEC j)) := by
    apply Finset.fold_congr
    intro j hj
    simp only [hcanFs_def, canonicalFinset, Finset.mem_filter,
      Finset.mem_univ, true_and] at hj
    show ECPoint.zsmul E (c (bEC j)) (bEC j) = _
    rw [hc_def, hbEC_def,
        extractorDivisorCoeffs_basesAffineEC_of_canonical E stmt msg hkm hNoNegP j hj]
  rw [hFoldCongr]
  -- Step D: extend canonical sum to univ via zero-padding.
  show canFs.fold (ECPoint.add E) 0 _ = ECPoint.weightedSum E _ _
  apply (ECPoint.weightedSum_subset_of_zero_outside E (Finset.subset_univ canFs) ?_).symm
  intro j _ hjnotcanon
  simp only [hcanFs_def, canonicalFinset, Finset.mem_filter,
    Finset.mem_univ, true_and] at hjnotcanon
  exact zsmul_extractedScalars_basesAffineEC_zero_of_notCanonical
    E stmt msg hkm hNoNegP j hjnotcanon

/-- Support of `extractorDivisorCoeffs` is contained in the candidate Finset
    `{∞, -P_aff} ∪ image(basesAffineEC)`. -/
theorem extractorDivisorCoeffs_support_subset_candidate
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    Function.support (extractorDivisorCoeffs E stmt msg hkm) ⊆
    ↑(extractorDivisorCandidate E stmt msg hkm) := by
  classical
  intro P hP
  simp only [Function.mem_support] at hP
  rw [Finset.mem_coe]
  unfold extractorDivisorCandidate
  cases P with
  | infinity =>
      exact Finset.mem_insert_self _ _
  | affine x y =>
      refine Finset.mem_insert_of_mem ?_
      by_cases hxy : (x, y) = (stmt.target.1, -stmt.target.2)
      · rw [Prod.mk.injEq] at hxy
        rcases hxy with ⟨hx, hy⟩
        rw [hx, hy]
        exact Finset.mem_insert_self _ _
      · refine Finset.mem_insert_of_mem ?_
        -- Indicator = 0, so filter-sum ≠ 0, so filter is nonempty.
        have hEval : extractorDivisorCoeffs E stmt msg hkm
                        (ECPoint.affine x y) =
                      0 + ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
                        (fun j => extractorBases E stmt msg hkm j = (x, y)),
                        extractedScalars E stmt msg hkm j := by
          show (if (x, y) = (stmt.target.1, -stmt.target.2)
                then (1 : ℤ) else 0) +
               ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
                 (fun j => extractorBases E stmt msg hkm j = (x, y)),
                 extractedScalars E stmt msg hkm j = _
          rw [if_neg hxy]
        rw [hEval, zero_add] at hP
        by_contra hNotInImage
        apply hP
        have hEmpty : ((Finset.univ : Finset (Fin msg.k)).filter
            (fun j => extractorBases E stmt msg hkm j = (x, y))) = ∅ := by
          rw [Finset.eq_empty_iff_forall_notMem]
          intro j hj
          simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj
          apply hNotInImage
          refine Finset.mem_image.mpr ⟨j, Finset.mem_univ _, ?_⟩
          simp only [hj]
        rw [hEmpty, Finset.sum_empty]

/-- `∞` is not an affine point, so not in the `basesAffineEC` image. -/
theorem infinity_notin_image_basesAffineEC
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    ECPoint.infinity ∉
    ((Finset.univ : Finset (Fin msg.k)).image (basesAffineEC E stmt msg hkm)) := by
  intro hContra
  rw [Finset.mem_image] at hContra
  obtain ⟨j, _, heq⟩ := hContra
  unfold basesAffineEC at heq
  cases heq

/-- Under general case, `-P_aff` is not in the image of base points. -/
theorem negP_notin_image_basesAffineEC
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty) :
    (ECPoint.affine stmt.target.1 (-stmt.target.2) : ECPoint E.q) ∉
    ((Finset.univ : Finset (Fin msg.k)).image (basesAffineEC E stmt msg hkm)) := by
  intro hContra
  rw [Finset.mem_image] at hContra
  obtain ⟨j, _, heq⟩ := hContra
  apply hNoNegP
  refine ⟨j, ?_⟩
  simp only [negPIndexSet, Finset.mem_filter, Finset.mem_univ, true_and]
  unfold basesAffineEC at heq
  have hprod : (extractorBases E stmt msg hkm j).1 = stmt.target.1 ∧
               (extractorBases E stmt msg hkm j).2 = -stmt.target.2 := by
    have := ECPoint.affine.injEq .. |>.mp heq
    exact this
  exact Prod.ext hprod.1 hprod.2

/-- `∞ ≠ -P_aff`. -/
theorem infinity_ne_negP_aff
    (stmt : DlogStatement E.q) :
    (ECPoint.infinity : ECPoint E.q) ≠
    ECPoint.affine stmt.target.1 (-stmt.target.2) := by
  intro h; cases h

/-- `∞` is not in `insert (-P_aff) (image basesAffineEC)`. -/
theorem infinity_notin_insert_negP_image
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    (ECPoint.infinity : ECPoint E.q) ∉
    insert (ECPoint.affine stmt.target.1 (-stmt.target.2))
      ((Finset.univ : Finset (Fin msg.k)).image (basesAffineEC E stmt msg hkm)) := by
  intro hContra
  rw [Finset.mem_insert] at hContra
  rcases hContra with h | h
  · exact infinity_ne_negP_aff E stmt h
  · exact infinity_notin_image_basesAffineEC E stmt msg hkm h

/-- **D4 main theorem.** If `extractorDivisorCoeffs` is the divisor of a
    rational function on `E` (i.e., `IsPrincipal`), then the group-law
    equation `(-P) + Σ [extractedScalars i] · B_i = 0` holds.

    Combined with D5 (`target_eq_weightedSum_of_zero_sum`), this gives
    the full group-law conclusion `target = Σ [extractedScalars i] · B_i`. -/
theorem extractor_zeroSum_of_principal
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (hPrincipal : IsPrincipal E (extractorDivisorCoeffs E stmt msg hkm)) :
    ECPoint.add E
      (ECPoint.affine stmt.target.1 (-stmt.target.2))
      (ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
        (fun i => ECPoint.zsmul E (extractedScalars E stmt msg hkm i)
          (basesAffineEC E stmt msg hkm i)))
    = 0 := by
  classical
  set c := extractorDivisorCoeffs E stmt msg hkm with hc_def
  set candFs := extractorDivisorCandidate E stmt msg hkm
  -- Step 1-2: finite support.
  have hSupSub : Function.support c ⊆ ↑candFs :=
    extractorDivisorCoeffs_support_subset_candidate E stmt msg hkm
  have hFinSupp : Set.Finite (Function.support c) :=
    (Finset.finite_toSet candFs).subset hSupSub
  -- Step 3: principal_divisor_iff.
  have ⟨_, hGroup⟩ := (principal_divisor_iff E c hFinSupp).mp hPrincipal
  -- Step 4: extend group-sum from support to candidate Finset.
  have hFinSupp_sub_candFs : hFinSupp.toFinset ⊆ candFs := by
    intro P hP
    rw [Set.Finite.mem_toFinset] at hP
    exact hSupSub hP
  have hCandSum :
      ECPoint.weightedSum E candFs (fun P => ECPoint.zsmul E (c P) P) = 0 := by
    rw [ECPoint.weightedSum_subset_of_zero_outside E hFinSupp_sub_candFs ?_]
    · exact hGroup
    · intro P _ hPnotSup
      rw [Set.Finite.mem_toFinset, Function.mem_support, not_not] at hPnotSup
      rw [hPnotSup]
      exact ECPoint.zsmul_zero E P
  -- Step 5: expand weightedSum over candidate Finset.
  have hCandExpand :
      ECPoint.weightedSum E candFs (fun P => ECPoint.zsmul E (c P) P) =
      ECPoint.add E
        (ECPoint.affine stmt.target.1 (-stmt.target.2))
        (ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
          (fun i => ECPoint.zsmul E (extractedScalars E stmt msg hkm i)
            (basesAffineEC E stmt msg hkm i))) := by
    show ECPoint.weightedSum E
      (insert (ECPoint.infinity : ECPoint E.q)
        (insert (ECPoint.affine stmt.target.1 (-stmt.target.2))
          ((Finset.univ : Finset (Fin msg.k)).image (basesAffineEC E stmt msg hkm))))
      (fun P => ECPoint.zsmul E (c P) P) = _
    rw [ECPoint.weightedSum_insert E (infinity_notin_insert_negP_image E stmt msg hkm)]
    have h_f_inf : ECPoint.zsmul E (c ECPoint.infinity) ECPoint.infinity = 0 := by
      rw [hc_def]
      rw [extractorDivisorCoeffs_infinity]
      exact ECPoint.zsmul_infinity E _
    rw [h_f_inf, ECPoint.zero_add_curve]
    rw [ECPoint.weightedSum_insert E (negP_notin_image_basesAffineEC E stmt msg hkm hNoNegP)]
    have h_f_negP :
        ECPoint.zsmul E (c (ECPoint.affine stmt.target.1 (-stmt.target.2)))
          (ECPoint.affine stmt.target.1 (-stmt.target.2))
        = ECPoint.affine stmt.target.1 (-stmt.target.2) := by
      rw [hc_def, extractorDivisorCoeffs_negP E stmt msg hkm hNoNegP]
      exact ECPoint.zsmul_one E _
    rw [h_f_negP]
    congr 1
    exact weightedSum_imageBases_eq_univ_zsmul_extractedScalars E stmt msg hkm hNoNegP
  rw [← hCandExpand]
  exact hCandSum

/-! ## D3: extractor bound from a natural-number witness

The "σ-matching" output of `log_deriv_nonvanishing_criterion` identifies
the integer multiplicity `β_k` of each zero `Q_k` of `D` with a
canonical position `i = σ(k)` in the bases, satisfying
`β_k + groupSum i = 0` in `ZMod q`. The paper's extractor recovers
`β_{σ⁻¹(i)}` from `-groupSum i` via the `.val` lift in the `-P ∉ {B_j}`
branch of `extractedScalars`.

`extractorSucceeds_of_natural_witness` abstracts the σ-matching output
as a single `coeff : Fin msg.k → ℕ` satisfying three properties:
* `coeff i < d` for every i (the soundness bound, derived from
  `β_k ≤ D.degE ≤ d` in full T4 assembly).
* `(coeff i : ZMod E.q) = -(groupSum i)` at canonical i (the residue-
  matching identity).
* `coeff i = 0` at non-canonical i (matching the extractor's zero
  assignment at non-canonical positions).

The theorem outputs both the extractor-range conclusion
(`extractorSucceeds`) and the point-level identification
`extractedScalars i = coeff i` (for feeding into D4+D5).
-/

theorem extractorSucceeds_of_natural_witness
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hd : d < E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (coeff : Fin msg.k → ℕ)
    (hCoeff_bound : ∀ i, coeff i < d)
    (hCoeff_zmod : ∀ i, extractorIsCanonical E stmt msg hkm i →
      (coeff i : ZMod E.q) = extractorGroupSum E stmt msg hkm i)
    (hCoeff_noncanon : ∀ i, ¬ extractorIsCanonical E stmt msg hkm i →
      coeff i = 0) :
    extractorSucceeds E stmt msg d hkm ∧
    ∀ i, extractedScalars E stmt msg hkm i = (coeff i : ℤ) := by
  classical
  -- Step 1: show extractedScalars i = (coeff i : ℤ) for every i.
  have hScalars_eq : ∀ i, extractedScalars E stmt msg hkm i = (coeff i : ℤ) := by
    intro i
    show (if hNegP : (negPIndexSet E stmt msg hkm).Nonempty
          then (if i = (negPIndexSet E stmt msg hkm).min' hNegP
                then (-1 : ℤ) else 0)
          else if extractorIsCanonical E stmt msg hkm i
               then ((extractorGroupSum E stmt msg hkm i).val : ℤ)
               else 0) = _
    rw [dif_neg hNoNegP]
    by_cases hC : extractorIsCanonical E stmt msg hkm i
    · rw [if_pos hC]
      have h1 : (coeff i : ZMod E.q) = extractorGroupSum E stmt msg hkm i :=
        hCoeff_zmod i hC
      have hBound : coeff i < E.q := lt_of_lt_of_le (hCoeff_bound i) (le_of_lt hd)
      have h2 : ((extractorGroupSum E stmt msg hkm i : ZMod E.q)).val = coeff i := by
        rw [← h1]
        exact ZMod.val_natCast_of_lt hBound
      rw [h2]
    · rw [if_neg hC]
      rw [hCoeff_noncanon i hC, Nat.cast_zero]
  refine ⟨?_, hScalars_eq⟩
  -- Step 2: extractorSucceeds from the bound on coeff.
  intro i
  rw [hScalars_eq i, Int.natAbs_natCast]
  exact hCoeff_bound i

/-! ## D5: target from zero-sum of the extractor's divisor

In the general case (`-P ∉ {B_j}`), D's divisor of zeros on `E` is
`(-P) + Σ [extractedScalars i] · B_i - D.degE · ∞` (with the `-P` term
carrying the `+1` corresponding to D's simple zero there).
Principality of this divisor (= D being a rational function on E) says
that the sum of this divisor's group-evaluation is `0` in the group:

  `(-P) + Σ [extractedScalars i] · B_i = 0`

(the `∞` term contributes `0` since `∞` is the group zero). This
theorem takes the zero-sum as hypothesis and derives
`target = Σ [extractedScalars i] · B_i` via left-cancellation by `(-P)`.
-/

theorem target_eq_weightedSum_of_zero_sum
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hZeroSum :
      ECPoint.add E
        (ECPoint.affine stmt.target.1 (-stmt.target.2))
        (ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
          (fun i => ECPoint.zsmul E (extractedScalars E stmt msg hkm i)
            (ECPoint.affine (extractorBases E stmt msg hkm i).1
                            (extractorBases E stmt msg hkm i).2)))
      = 0) :
    ECPoint.affine stmt.target.1 stmt.target.2 =
      ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
        (fun i => ECPoint.zsmul E (extractedScalars E stmt msg hkm i)
          (ECPoint.affine (extractorBases E stmt msg hkm i).1
                          (extractorBases E stmt msg hkm i).2)) := by
  set P_aff := (ECPoint.affine stmt.target.1 stmt.target.2 : ECPoint E.q)
  set X := ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
    (fun i => ECPoint.zsmul E (extractedScalars E stmt msg hkm i)
      (ECPoint.affine (extractorBases E stmt msg hkm i).1
                      (extractorBases E stmt msg hkm i).2)) with hX_def
  -- The `-P` affine point is the ECPoint negation of `P_aff`.
  have hPneg : (ECPoint.affine stmt.target.1 (-stmt.target.2) : ECPoint E.q) =
               -P_aff := rfl
  rw [hPneg] at hZeroSum
  -- `add (-P_aff) P_aff = 0` by `neg_add_cancel`.
  have hNegCancel : ECPoint.add E (-P_aff) P_aff = 0 :=
    ECPoint.neg_add_cancel E P_aff
  -- Conclude `X = P_aff` by left cancellation.
  have hEq : ECPoint.add E (-P_aff) X = ECPoint.add E (-P_aff) P_aff := by
    rw [hZeroSum, hNegCancel]
  exact (ECPoint.add_left_cancel E hEq).symm

/-- **D4+D5 combined.** Given principality of the extractor's divisor
    coefficient function (`extractorDivisorCoeffs`), conclude
    `target = Σ [extractedScalars i] · B_i`. -/
theorem target_eq_weightedSum_of_principal
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (hPrincipal : IsPrincipal E (extractorDivisorCoeffs E stmt msg hkm)) :
    ECPoint.affine stmt.target.1 stmt.target.2 =
      ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
        (fun i => ECPoint.zsmul E (extractedScalars E stmt msg hkm i)
          (ECPoint.affine (extractorBases E stmt msg hkm i).1
                          (extractorBases E stmt msg hkm i).2)) := by
  exact target_eq_weightedSum_of_zero_sum E stmt msg hkm
    (extractor_zeroSum_of_principal E stmt msg hkm hNoNegP hPrincipal)

/-! ## Distinct-base-point enumeration

    `log_deriv_nonvanishing_criterion` (T5) requires the `R` family
    passed to `polyG` to be injective. The raw `R = Fin.cons (-P_aff) B`
    may have duplicates among `B`'s positions (the extractor handles
    this via `extractorGroup` + canonical-index selection). This
    section enumerates the distinct bases as a Finset, and lifts to
    a `Fin`-indexing.

    Combined with `-P_aff` (which is outside the base image under
    `hNoNegP`), we get a distinct `R : Fin (1 + baseImageCount) →
    (ZMod E.q)²` via `Fin.cons`.
-/

/-- Finset of distinct base points. -/
noncomputable def baseImage
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) : Finset (ZMod E.q × ZMod E.q) :=
  (Finset.univ : Finset (Fin msg.k)).image (extractorBases E stmt msg hkm)

/-- Number of distinct base points. -/
noncomputable def baseImageCount
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) : ℕ :=
  (baseImage E stmt msg hkm).card

/-- Enumeration of distinct base points. -/
noncomputable def baseImageEnum
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    Fin (baseImageCount E stmt msg hkm) ≃ (baseImage E stmt msg hkm) :=
  (baseImage E stmt msg hkm).equivFin.symm

/-- The `k`-th distinct base point (as an ordered pair). -/
noncomputable def baseAt
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (k : Fin (baseImageCount E stmt msg hkm)) :
    ZMod E.q × ZMod E.q :=
  ((baseImageEnum E stmt msg hkm k) : ZMod E.q × ZMod E.q)

theorem baseAt_mem_baseImage
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (k : Fin (baseImageCount E stmt msg hkm)) :
    baseAt E stmt msg hkm k ∈ baseImage E stmt msg hkm :=
  (baseImageEnum E stmt msg hkm k).2

theorem baseAt_injective
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    Function.Injective (baseAt E stmt msg hkm) := by
  intro k₁ k₂ heq
  apply (baseImageEnum E stmt msg hkm).injective
  exact Subtype.ext heq

/-- Under `hNoNegP`, `-P_aff` is not in the base image. -/
theorem negP_notin_baseImage
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty) :
    (stmt.target.1, -stmt.target.2) ∉ baseImage E stmt msg hkm := by
  intro hContra
  rw [baseImage, Finset.mem_image] at hContra
  obtain ⟨i, _, heq⟩ := hContra
  apply hNoNegP
  exact ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ _, heq⟩⟩

/-- Under `hNoNegP`, `baseAt k ≠ -P_aff` for any `k`. -/
theorem baseAt_ne_negP
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (k : Fin (baseImageCount E stmt msg hkm)) :
    baseAt E stmt msg hkm k ≠ (stmt.target.1, -stmt.target.2) := by
  intro heq
  exact negP_notin_baseImage E stmt msg hkm hNoNegP
    (heq ▸ baseAt_mem_baseImage E stmt msg hkm k)

/-! ## Distinct-R enumeration (S1)

    `log_deriv_nonvanishing_criterion` (T5) demands an injective
    `R : Fin M → (ZMod E.q)²` family. We form it as
    `Fin.cons (P.1, -P.2) baseAt`: the head is `-P_aff`, the tail
    enumerates the distinct base points. Under `hNoNegP`,
    `-P_aff` is outside the base image (`baseAt_ne_negP`) and
    `baseAt` is already injective, so the combined family is injective.

    The length is packaged as `1 + baseImageCount` (matching T5's
    expected shape `1 + M`); internally we reuse `Fin.cons` which
    produces a `Fin (n + 1)`-indexed family and compose with
    `finCongr (Nat.add_comm _ _)`. -/

/-- Underlying `Fin.cons`-based family `Fin (n + 1) → ZMod² E.q`. -/
noncomputable def distinctRCons
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    Fin (baseImageCount E stmt msg hkm + 1) → ZMod E.q × ZMod E.q :=
  Fin.cons (α := fun _ => ZMod E.q × ZMod E.q)
    (stmt.target.1, -stmt.target.2) (baseAt E stmt msg hkm)

@[simp] theorem distinctRCons_zero
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    distinctRCons E stmt msg hkm 0 = (stmt.target.1, -stmt.target.2) := by
  simp [distinctRCons]

@[simp] theorem distinctRCons_succ
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctRCons E stmt msg hkm i.succ = baseAt E stmt msg hkm i := by
  simp [distinctRCons]

theorem distinctRCons_injective
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty) :
    Function.Injective (distinctRCons E stmt msg hkm) := by
  refine Fin.cons_injective_of_injective ?_ (baseAt_injective E stmt msg hkm)
  rintro ⟨i, hi⟩
  exact baseAt_ne_negP E stmt msg hkm hNoNegP i hi

/-- Distinct-R family: `-P_aff` prepended to the distinct base points.
    Length `1 + baseImageCount`. Used as the `R` parameter for T5. -/
noncomputable def distinctR
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    Fin (1 + baseImageCount E stmt msg hkm) → ZMod E.q × ZMod E.q :=
  distinctRCons E stmt msg hkm ∘
    finCongr (Nat.add_comm 1 (baseImageCount E stmt msg hkm))

@[simp] theorem distinctR_zero
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    distinctR E stmt msg hkm ⟨0, by omega⟩ = (stmt.target.1, -stmt.target.2) := by
  unfold distinctR
  have : (finCongr (Nat.add_comm 1 (baseImageCount E stmt msg hkm))
            ⟨0, by omega⟩ : Fin (baseImageCount E stmt msg hkm + 1))
         = 0 := rfl
  simp [Function.comp_apply, this, distinctRCons_zero]

@[simp] theorem distinctR_succ
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctR E stmt msg hkm ⟨i.val + 1, by omega⟩
      = baseAt E stmt msg hkm i := by
  unfold distinctR
  have hEq : (finCongr (Nat.add_comm 1 (baseImageCount E stmt msg hkm))
                ⟨i.val + 1, by omega⟩ : Fin (baseImageCount E stmt msg hkm + 1))
             = i.succ := by
    apply Fin.ext
    rfl
  simp [Function.comp_apply, hEq, distinctRCons_succ]

/-- Under `hNoNegP`, `distinctR` is injective. Head is `-P_aff`,
    which is outside `baseAt`'s range (`baseAt_ne_negP`); tail is
    injective (`baseAt_injective`). -/
theorem distinctR_injective
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty) :
    Function.Injective (distinctR E stmt msg hkm) := by
  unfold distinctR
  exact (distinctRCons_injective E stmt msg hkm hNoNegP).comp
    (finCongr _).injective

/-! ## Grouped coefficient enumeration (S2)

    Companion to `distinctR`: the grouped-coefficient family `distinctM'`
    of type `Fin (1 + baseImageCount) → ZMod E.q`, with head `-1` and
    tail `extractorGroupSum` at the canonical index whose base is
    `baseAt i`.

    T5 (`log_deriv_nonvanishing_criterion`) takes a raw `(R, m)` pair on
    `Fin k`; for the extractor application we replace it with the
    distinct-base pair `(distinctR, distinctM')` on
    `Fin (1 + baseImageCount)`, where repeats in the raw `R` are folded
    into `ZMod`-sums in `m` at their common base point.

    The tail's `j`-choice is made via `Classical.choose` on the witness
    of `baseAt i ∈ baseImage`; `distinctM'_tail_group_invariant` below
    shows the resulting value depends only on the base point, not on
    the chosen representative. That independence is essential for the
    S3 raw-to-distinct polyG bridge.
-/

/-- For any `i : Fin (baseImageCount ...)`, `baseAt i` lies in
    `baseImage`, i.e. is in the `extractorBases`-image of `Finset.univ`;
    hence there exists `j : Fin msg.k` with `extractorBases j = baseAt i`. -/
theorem exists_extractorBases_eq_baseAt
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    ∃ j : Fin msg.k, extractorBases E stmt msg hkm j
      = baseAt E stmt msg hkm i := by
  have hmem := baseAt_mem_baseImage E stmt msg hkm i
  rw [baseImage, Finset.mem_image] at hmem
  obtain ⟨j, _, hj⟩ := hmem
  exact ⟨j, hj⟩

/-- Canonical index choice for a distinct base point: some
    `j : Fin msg.k` with `extractorBases j = baseAt i`. -/
noncomputable def baseAtIndex
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    Fin msg.k :=
  (exists_extractorBases_eq_baseAt E stmt msg hkm i).choose

theorem baseAtIndex_spec
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    extractorBases E stmt msg hkm (baseAtIndex E stmt msg hkm i)
      = baseAt E stmt msg hkm i :=
  (exists_extractorBases_eq_baseAt E stmt msg hkm i).choose_spec

/-- `extractorGroupSum` depends only on the base point, not on the
    representative index. Concretely, if `extractorBases j₁ =
    extractorBases j₂` then the two indices share a group (by
    `extractedScalars_group_canonical`) and hence produce the same
    `extractorGroupSum`. -/
theorem extractorGroupSum_congr_of_extractorBases_eq
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) {j₁ j₂ : Fin msg.k}
    (h : extractorBases E stmt msg hkm j₁
      = extractorBases E stmt msg hkm j₂) :
    extractorGroupSum E stmt msg hkm j₁
      = extractorGroupSum E stmt msg hkm j₂ := by
  have hj₁inG₂ : j₁ ∈ extractorGroup E stmt msg hkm j₂ :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩
  have hGeq : extractorGroup E stmt msg hkm j₁
      = extractorGroup E stmt msg hkm j₂ :=
    extractedScalars_group_canonical E stmt msg hkm j₂ j₁ hj₁inG₂
  simp [extractorGroupSum, hGeq]

/-- Underlying `Fin.cons`-based family `Fin (n + 1) → ZMod E.q` for
    the grouped coefficients. Head `-1`, tail
    `-extractorGroupSum` at the chosen `baseAtIndex`.

    The tail is NEGATED (vs. the raw `extractorGroupSum`) to align
    with the narrow scalar polyG-bridge axiom's sign convention
    (`Fin.cons (-1) (fun j => -m j)`). The negation reconciles the
    additive sign of `polyG`'s second sum (`Σ m'·prods`) with
    `logDerivCheckFn`'s RHS sum coefficient (`-m_j / L(B_j)`) and
    the Lemma 6 residue identity `Σ β_k/L(Q_k) = 1/L(-P) + Σ m_j/L(B_j)`.
    See Session 41's sign-resolution note and ResidueIdentity.lean. -/
noncomputable def distinctMCons
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    Fin (baseImageCount E stmt msg hkm + 1) → ZMod E.q :=
  Fin.cons (α := fun _ => ZMod E.q) (-1 : ZMod E.q)
    (fun i : Fin (baseImageCount E stmt msg hkm) =>
      -extractorGroupSum E stmt msg hkm (baseAtIndex E stmt msg hkm i))

@[simp] theorem distinctMCons_zero
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    distinctMCons E stmt msg hkm 0 = (-1 : ZMod E.q) := by
  simp [distinctMCons]

@[simp] theorem distinctMCons_succ
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctMCons E stmt msg hkm i.succ
      = -extractorGroupSum E stmt msg hkm
          (baseAtIndex E stmt msg hkm i) := by
  simp [distinctMCons]

/-- Grouped coefficient family: `-1` at the `-P_aff` head, then
    `-extractorGroupSum` per distinct base. Length `1 + baseImageCount`,
    matching `distinctR`'s shape so the pair feeds T5's `Fin M` form.

    Note: the tail is NEGATED (Session 41 sign resolution) to align
    `polyG`'s additive convention with `logDerivCheckFn`'s RHS sign on
    the `m_j` coefficients. -/
noncomputable def distinctM'
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    Fin (1 + baseImageCount E stmt msg hkm) → ZMod E.q :=
  distinctMCons E stmt msg hkm ∘
    finCongr (Nat.add_comm 1 (baseImageCount E stmt msg hkm))

@[simp] theorem distinctM'_zero
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) :
    distinctM' E stmt msg hkm ⟨0, by omega⟩ = (-1 : ZMod E.q) := by
  unfold distinctM'
  have : (finCongr (Nat.add_comm 1 (baseImageCount E stmt msg hkm))
            ⟨0, by omega⟩ : Fin (baseImageCount E stmt msg hkm + 1))
         = 0 := rfl
  simp [Function.comp_apply, this, distinctMCons_zero]

@[simp] theorem distinctM'_succ
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctM' E stmt msg hkm ⟨i.val + 1, by omega⟩
      = -extractorGroupSum E stmt msg hkm
          (baseAtIndex E stmt msg hkm i) := by
  unfold distinctM'
  have hEq : (finCongr (Nat.add_comm 1 (baseImageCount E stmt msg hkm))
                ⟨i.val + 1, by omega⟩ : Fin (baseImageCount E stmt msg hkm + 1))
             = i.succ := by
    apply Fin.ext
    rfl
  simp [Function.comp_apply, hEq, distinctMCons_succ]

/-- **Representative independence**: `distinctM' ⟨i+1, _⟩` equals
    `-extractorGroupSum` at *any* `j` with `extractorBases j = baseAt i`,
    not just the `Classical.choose` representative.

    Proof: by `distinctM'_succ`, the LHS reduces to
    `-extractorGroupSum E stmt msg hkm (baseAtIndex ... i)`. The
    `baseAtIndex` representative shares a base with `baseAt i`, i.e.
    with `j`, so
    `extractorGroupSum_congr_of_extractorBases_eq` collapses both to
    the same value. Essential for S3's raw↔distinct polyG bridge. -/
theorem distinctM'_tail_group_invariant
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm))
    (j : Fin msg.k)
    (hj : extractorBases E stmt msg hkm j = baseAt E stmt msg hkm i) :
    distinctM' E stmt msg hkm ⟨i.val + 1, by omega⟩
      = -extractorGroupSum E stmt msg hkm j := by
  rw [distinctM'_succ]
  have hspec := baseAtIndex_spec E stmt msg hkm i
  congr 1
  exact extractorGroupSum_congr_of_extractorBases_eq E stmt msg hkm
    (hspec.trans hj.symm)

/-! ## Narrow polyG-bridge (scalar level) — Phase 4 replacement

    The remaining classical content of the old composite
    T4 bridge that is NOT covered by
    `CoordRingElt.has_principal_divisor` (= Silverman III.3.5) is the
    paper's residue / denominator-clearing identity: if the scalar
    `logDerivCheckFn` vanishes on the defined non-vertical challenge
    subspace of `E × E`, then the denominator-cleared polynomial
    `polyG` (formed with `D`'s divisor data `(Q, β)`) vanishes on the
    non-vertical subspace of `E × E`.

    **Phase 4 status**: the former transient axiom
    `polyG_zero_of_logDerivCheck_identically_zero` has been converted
    to a theorem (by the narrowing strategy of Fallback C in
    `docs/continuation-plan.md`). The theorem takes one additional
    hypothesis — `hPolyGZero` — supplying the scalar conclusion
    (`polyG = 0` at every non-vertical pair) directly. This
    hypothesis packages the two remaining unmechanized pieces:
    Lemma 6's function-field chord-residue identity and the density
    argument transferring vanishing from defined pairs to all
    non-vertical pairs.

    `ma_extractable` now takes `hPolyGZero` as an extra hypothesis,
    which a future phase can discharge by finishing Lemma 6
    (requires mechanizing `chordLogDerivMatchesNormZ` from
    `Divisor/Lemma6.lean`; Phase 3 reduced Lemma 6 to that scalar
    equality) and the density argument.

    Paper context: (i) Lemma 6 (norm decomposition
    `N(D) = ∏ (z − z(Q_k))^{β_k}`), (ii) the log-derivative formula
    `L(N(D)) = Σ β_k / (z − z(Q_k))`, (iii) the `ellP = L_Q · (X₁ − X₀)`
    denominator-clearing step (already mechanized via
    `polyG_eq_zero_iff_paperResidue` in `Divisor/ResidueIdentity.lean`),
    (iv) the density argument transferring vanishing from `defined`
    pairs to all non-vertical pairs on `E × E`.

    Citation: Silverman Ch II §2 (local uniformizers, order of vanishing)
    + Ch III §3 (principal divisors). -/

/-- **Phase 4 replacement theorem** for the old narrow axiom
    `polyG_zero_of_logDerivCheck_identically_zero`. The former
    axiom's premises plus the new hypothesis `hPolyGZero` entail the
    conclusion.

    Hypotheses encode `D`'s divisor data `(Q, β)` (obtainable via
    `CoordRingElt.has_principal_divisor`):
    * `Q : Fin d → (ZMod E.q)²` enumerates `D`'s distinct affine
      zeros on `E`,
    * `β : Fin d → ℕ` their natural-number multiplicities summing to
      `D.degE`,
    * `R = Fin.cons (P.1, -P.2) B` packages the RHS residue points,
    * `m' = Fin.cons (-1) (fun j => -m j)` packages the RHS residue
      coefficients with the sign convention needed to align with
      Lean's `logDerivCheckFn` (whose `rhs` has coefficient `-m_j` on
      `L(B_j)⁻¹`) against `polyG`'s additive sign convention
      `Σβ·prods + Σm'·prods`. See Session 41's sign-resolution note.

    Conclusion: `polyG` vanishes on all non-vertical pairs of `E × E`.

    `hPolyGZero` is the consolidated "Lemma 6 + density" hypothesis:
    it asserts `polyG = 0` at every non-vertical E-pair for the
    specific `(Q, β_fun, R, m')` data. Phase 4 narrows the axiom by
    taking this as a hypothesis; a future phase can discharge it by
    completing Lemma 6 (Phase 3 infrastructure in
    `Divisor/Lemma6.lean`) and the density argument (polynomial form
    `polyGPoly` from `Divisor/PolyGBridge.lean` + `card_zeros_on_E_le`
    from `Divisor/CubicIntersection.lean`). -/
theorem polyG_zero_of_logDerivCheck_identically_zero
    (D : CoordRingElt E.q) (_hD : ¬ D.isZero)
    (P : ZMod E.q × ZMod E.q) (k : ℕ)
    (B : Fin k → ZMod E.q × ZMod E.q) (m : Fin k → ZMod E.q)
    (_hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E D P B A₀ A₁ →
      logDerivCheckFn E D P k B m A₀ A₁ = 0)
    {d : ℕ}
    (Q : Fin d → ZMod E.q × ZMod E.q)
    (beta : Fin d → ℕ)
    (_hQinj : Function.Injective Q)
    (_hQzeros : ∀ k' : Fin d,
       Q k' ∈ E.points ∧ D.eval (Q k').1 (Q k').2 = 0)
    (_hQcov : ∀ Q' ∈ E.points, D.eval Q'.1 Q'.2 = 0 →
       ∃ k' : Fin d, Q k' = Q')
    (_hβPos : ∀ k', beta k' > 0)
    (_hβSum : (∑ k' : Fin d, beta k') = D.degE)
    (hPolyGZero :
      ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
        A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
        polyG E Q (fun k' => ((beta k' : ℕ) : ZMod E.q))
                  (Fin.cons (P.1, -P.2) B)
                  (Fin.cons (-1) (fun j => -m j))
                  A₀ A₁ = 0)
    (A₀ A₁ : ZMod E.q × ZMod E.q)
    (hA₀ : A₀ ∈ E.points) (hA₁ : A₁ ∈ E.points) (hNV : A₀.1 ≠ A₁.1) :
    polyG E Q (fun k' => ((beta k' : ℕ) : ZMod E.q))
              (Fin.cons (P.1, -P.2) B)
              (Fin.cons (-1) (fun j => -m j))
              A₀ A₁ = 0 :=
  hPolyGZero A₀ A₁ hA₀ hA₁ hNV

/-! ## S3: raw → distinct polyG bridge

    Combine the narrow scalar axiom `polyG_zero_of_logDerivCheck_identically_zero`
    with the distinct-base enumeration (`distinctR` / `distinctM'` from S1+S2)
    to obtain vanishing of `polyG` in distinct form.

    Strategy: two layers.

    * **Layer A (scalar invariance)**: `logDerivCheckFn` with raw
      `(stmt.bases, fun i => msg.m (hkm ▸ i))` equals
      `logDerivCheckFn` with distinct
      `(baseAt, distinctM'_tail)`. Follows from fiberwise decomposition
      of `Fin msg.k` by `extractorBases`: each fiber has constant base
      `baseAt i`, so the raw sum `Σ -msg.m_j · L(stmt.bases j)⁻¹`
      collapses to `Σ -extractorGroupSum_i · L(baseAt i)⁻¹`.
    * **Layer B (apply narrow axiom)**: feed the narrow axiom with
      `k := baseImageCount`, `B := baseAt`, `m := distinctM'_tail`.
      Its `hAllZero` precondition becomes the distinct form, which we
      derive from the raw form via Layer A. Its conclusion is
      `polyG ... (Fin.cons (P.1,-P.2) baseAt)
               (Fin.cons (-1) (fun j => -distinctM'_tail j)) = 0`
      at index `Fin (baseImageCount + 1)`. The latter argument equals
      `distinctMCons` definitionally (post Session 41 sign fix).
      Reindexing by `finCongr (Nat.add_comm 1 _)` produces the
      `distinctR` / `distinctM'` form at index
      `Fin (1 + baseImageCount)`.
-/

/-- The tail of `distinctMCons`, exposed as a separate definition.
    Value is `extractorGroupSum` at the `Classical.choose` representative. -/
noncomputable def distinctM'_tail
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    ZMod E.q :=
  extractorGroupSum E stmt msg hkm (baseAtIndex E stmt msg hkm i)

/-- `distinctMCons` factors as the `-1` head `Fin.cons` (negated) tail
    `-distinctM'_tail`. -/
theorem distinctMCons_eq_cons
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    distinctMCons E stmt msg hkm =
      Fin.cons (α := fun _ => ZMod E.q) (-1 : ZMod E.q)
        (fun i => -distinctM'_tail E stmt msg hkm i) := rfl

/-- `distinctRCons` factors as the `-P_aff` head `Fin.cons` tail `baseAt`. -/
theorem distinctRCons_eq_cons
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k) :
    distinctRCons E stmt msg hkm =
      Fin.cons (α := fun _ => ZMod E.q × ZMod E.q)
        (stmt.target.1, -stmt.target.2) (baseAt E stmt msg hkm) := rfl

/-- Canonical fiber index: for `j : Fin msg.k`,
    `baseIndexOf j` is the unique `i : Fin (baseImageCount ...)` with
    `baseAt i = extractorBases j`. -/
noncomputable def baseIndexOf
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (j : Fin msg.k) :
    Fin (baseImageCount E stmt msg hkm) :=
  (baseImageEnum E stmt msg hkm).symm
    ⟨extractorBases E stmt msg hkm j,
      Finset.mem_image.mpr ⟨j, Finset.mem_univ _, rfl⟩⟩

theorem baseAt_baseIndexOf
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (j : Fin msg.k) :
    baseAt E stmt msg hkm (baseIndexOf E stmt msg hkm j)
      = extractorBases E stmt msg hkm j := by
  unfold baseAt baseIndexOf
  rw [Equiv.apply_symm_apply]

/-- The filter set `{j : Fin msg.k | extractorBases j = baseAt i}` equals
    `extractorGroup ... (baseAtIndex i)`. -/
theorem filter_extractorBases_eq_baseAt_eq_extractorGroup
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    ((Finset.univ : Finset (Fin msg.k)).filter
        (fun j => extractorBases E stmt msg hkm j
                    = baseAt E stmt msg hkm i))
      = extractorGroup E stmt msg hkm (baseAtIndex E stmt msg hkm i) := by
  ext j
  simp only [Finset.mem_filter, Finset.mem_univ, true_and,
    extractorGroup]
  rw [baseAtIndex_spec]

/-- `distinctM'_tail i` equals the sum of `msg.m` over the fiber of
    base point `baseAt i`. -/
theorem distinctM'_tail_eq_filter_sum
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctM'_tail E stmt msg hkm i
      = ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
              (fun j => extractorBases E stmt msg hkm j
                          = baseAt E stmt msg hkm i), msg.m j := by
  unfold distinctM'_tail extractorGroupSum
  rw [filter_extractorBases_eq_baseAt_eq_extractorGroup]

/-- **Layer A (scalar invariance)**: raw `logDerivCheckFn` with
    `(stmt.bases, fun i => msg.m (hkm ▸ i))` equals the distinct form
    with `(baseAt, distinctM'_tail)` at length `baseImageCount`. -/
theorem logDerivCheckFn_eq_grouped
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k) (D : CoordRingElt E.q) (P : ZMod E.q × ZMod E.q)
    (A₀ A₁ : ZMod E.q × ZMod E.q) :
    logDerivCheckFn E D P stmt.k stmt.bases (fun i => msg.m (hkm ▸ i))
        A₀ A₁
      = logDerivCheckFn E D P (baseImageCount E stmt msg hkm)
          (baseAt E stmt msg hkm) (distinctM'_tail E stmt msg hkm)
          A₀ A₁ := by
  classical
  -- Only the last sum differs. Unfold both forms and reduce to equality
  -- of the scalar sums.
  unfold logDerivCheckFn
  -- Both sides share `lhs - (-L(-P)⁻¹ + sum)`; reduce to `sum`-equality.
  simp only [sub_right_inj, add_right_inj]
  -- Step 1: reindex raw sum from Fin stmt.k to Fin msg.k.
  have hRaw :
      (Finset.univ : Finset (Fin stmt.k)).sum
          (fun j => -(msg.m (hkm ▸ j)) *
            ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
              (stmt.bases j).1 (stmt.bases j).2)⁻¹)
      = (Finset.univ : Finset (Fin msg.k)).sum
          (fun j => -(msg.m j) *
            ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
              (extractorBases E stmt msg hkm j).1
              (extractorBases E stmt msg hkm j).2)⁻¹) := by
    -- Both sides have the same underlying family parametrized by
    -- `.val`, so we prove equality by generalizing `stmt.k`.
    -- Use `Fintype.sum_equiv` with `finCongr hkm` and resolve the
    -- pointwise equality by `cases`-ing `hkm` (after generalizing
    -- `stmt.k`, `msg.m`, `stmt.bases` in sync).
    -- Simpler: prove via `Finset.sum_bij` with the bijection.
    refine Finset.sum_bij (fun j _ => finCongr hkm j)
      (fun _ _ => Finset.mem_univ _)
      ?_ -- injOn
      ?_ -- surjOn
      ?_ -- f equality
    · intro j _ j' _ h
      exact (finCongr hkm).injective h
    · intro j _
      refine ⟨(finCongr hkm).symm j, Finset.mem_univ _, ?_⟩
      simp
    · intro j _
      -- Show: -(msg.m (hkm ▸ j)) * L(stmt.bases j)⁻¹
      --     = -(msg.m (finCongr hkm j)) * L(extractorBases (finCongr hkm j))⁻¹.
      -- Both msg.m (hkm ▸ j) and msg.m (finCongr hkm j) equal via cast.
      -- Both L(stmt.bases j) and L(extractorBases (finCongr hkm j)) equal
      -- since extractorBases (finCongr hkm j) = stmt.bases (Fin.cast hkm.symm (finCongr hkm j))
      -- and Fin.cast hkm.symm (finCongr hkm j) = j (since ⟨j.val, _⟩ casts back).
      unfold extractorBases
      have hb : stmt.bases (Fin.cast hkm.symm (finCongr hkm j)) = stmt.bases j := by
        congr 1
      have hm : msg.m (hkm ▸ j) = msg.m (finCongr hkm j) := by
        congr 1
        -- Reduce to `(hkm ▸ j : Fin msg.k) = finCongr hkm j`. Both have
        -- `.val = j.val`; resolve by cases on `hkm`.
        generalize hn : msg.k = n at hkm
        subst hkm
        rfl
      rw [hb, hm]
  -- Step 2: fiberwise on RHS of step 1.
  rw [hRaw]
  -- Partition Fin msg.k by baseIndexOf.
  rw [← Finset.sum_fiberwise_of_maps_to
        (g := baseIndexOf E stmt msg hkm)
        (t := (Finset.univ : Finset (Fin (baseImageCount E stmt msg hkm))))
        (f := fun j => -(msg.m j) *
          ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
            (extractorBases E stmt msg hkm j).1
            (extractorBases E stmt msg hkm j).2)⁻¹)
        (fun _ _ => Finset.mem_univ _)]
  -- Replace each inner sum's filter by the baseAt-based filter.
  apply Finset.sum_congr rfl
  intro i _
  -- The inner filter `fun j => baseIndexOf j = i` equals
  -- `fun j => extractorBases j = baseAt i`.
  have hFilterEq :
      (Finset.univ : Finset (Fin msg.k)).filter
          (fun j => baseIndexOf E stmt msg hkm j = i)
        = (Finset.univ : Finset (Fin msg.k)).filter
            (fun j => extractorBases E stmt msg hkm j
                        = baseAt E stmt msg hkm i) := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    constructor
    · intro h
      rw [← h, baseAt_baseIndexOf]
    · intro h
      -- Goal: baseIndexOf j = i, given h : extractorBases j = baseAt i.
      -- Apply baseImageEnum (bijective), then reduce to the .val equality.
      unfold baseIndexOf
      apply (baseImageEnum E stmt msg hkm).symm_apply_eq.mpr
      apply Subtype.ext
      exact h
  rw [hFilterEq]
  -- Now the inner sum is over the filter `extractorBases j = baseAt i`.
  -- On this filter, `extractorBases j = baseAt i`, so the L(extractorBases j)⁻¹
  -- factor becomes L(baseAt i)⁻¹ (constant); pull it out:
  --   Σ j ∈ filter_i, -(msg.m j) · L(baseAt i)⁻¹
  --   = -L(baseAt i)⁻¹ · Σ j ∈ filter_i, msg.m j
  --   = -L(baseAt i)⁻¹ · distinctM'_tail i
  --   = -(distinctM'_tail i) · L(baseAt i)⁻¹
  have hInner :
      ∀ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
          (fun j => extractorBases E stmt msg hkm j
                      = baseAt E stmt msg hkm i),
        -(msg.m j) *
          ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
            (extractorBases E stmt msg hkm j).1
            (extractorBases E stmt msg hkm j).2)⁻¹
        = -(msg.m j) *
          ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
            (baseAt E stmt msg hkm i).1
            (baseAt E stmt msg hkm i).2)⁻¹ := by
    intro j hj
    have hjEq : extractorBases E stmt msg hkm j = baseAt E stmt msg hkm i :=
      (Finset.mem_filter.mp hj).2
    rw [hjEq]
  rw [Finset.sum_congr rfl hInner]
  -- Factor out the constant L(baseAt i)⁻¹.
  rw [← Finset.sum_mul]
  -- Σ j ∈ filter, -(msg.m j) = -(Σ j ∈ filter, msg.m j).
  rw [Finset.sum_neg_distrib]
  -- Σ j ∈ filter_i, msg.m j = distinctM'_tail i.
  rw [← distinctM'_tail_eq_filter_sum]

/-- **Main theorem (S3 — `Fin.cons` form)**: apply the narrow scalar
    bridge with `B := baseAt`, `m := distinctM'_tail`; its conclusion is
    in `Fin.cons`/`Fin (baseImageCount + 1)` form, matching `distinctRCons`
    and `distinctMCons`.

    Phase 4 update: the old narrow axiom has become a theorem that
    takes a `hPolyGZero` hypothesis. That hypothesis is threaded here
    as `hPolyGZeroCons` (at the `distinctRCons` / `distinctMCons`
    instantiation). -/
theorem polyG_distinct_zero_cons
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k)
    (hD : ¬ msg.toD.isZero)
    (hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ →
      logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
        (fun i => msg.m (hkm ▸ i)) A₀ A₁ = 0)
    {d : ℕ}
    (Q : Fin d → ZMod E.q × ZMod E.q)
    (beta : Fin d → ℕ)
    (hQinj : Function.Injective Q)
    (hQzeros : ∀ k' : Fin d,
       Q k' ∈ E.points ∧ msg.toD.eval (Q k').1 (Q k').2 = 0)
    (hQcov : ∀ Q' ∈ E.points, msg.toD.eval Q'.1 Q'.2 = 0 →
       ∃ k' : Fin d, Q k' = Q')
    (hβPos : ∀ k', beta k' > 0)
    (hβSum : (∑ k' : Fin d, beta k') = msg.toD.degE)
    (hPolyGZeroCons :
      ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
        A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
        polyG E Q (fun k' => ((beta k' : ℕ) : ZMod E.q))
                  (distinctRCons E stmt msg hkm) (distinctMCons E stmt msg hkm)
                  A₀ A₁ = 0)
    (A₀ A₁ : ZMod E.q × ZMod E.q)
    (hA₀ : A₀ ∈ E.points) (hA₁ : A₁ ∈ E.points) (hNV : A₀.1 ≠ A₁.1) :
    polyG E Q (fun k' => ((beta k' : ℕ) : ZMod E.q))
              (distinctRCons E stmt msg hkm) (distinctMCons E stmt msg hkm)
              A₀ A₁ = 0 := by
  -- Distinct-form `hAllZero` from raw `hAllZero` via Layer A scalar
  -- invariance (`logDerivCheckFn_eq_grouped`). The `Defined` predicate
  -- takes `stmt.bases`; we need a version with `baseAt`. But the narrow
  -- axiom takes `logDerivCheckFnDefined E D P B A₀ A₁` with its own `B`,
  -- so we instantiate at `B := baseAt`.
  have hAllZero' :
      ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
        A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
        logDerivCheckFnDefined E msg.toD stmt.target
          (baseAt E stmt msg hkm) A₀ A₁ →
        logDerivCheckFn E msg.toD stmt.target
          (baseImageCount E stmt msg hkm)
          (baseAt E stmt msg hkm)
          (distinctM'_tail E stmt msg hkm) A₀ A₁ = 0 := by
    intro A₀ A₁ hA₀ hA₁ hNV hDefDistinct
    -- Translate `defined`-distinct to `defined`-raw at `stmt.bases`.
    have hDefRaw : logDerivCheckFnDefined E msg.toD stmt.target
        stmt.bases A₀ A₁ := by
      unfold logDerivCheckFnDefined logDerivCheckFnDenom at hDefDistinct ⊢
      -- Both denoms share the "common" prefix up to and including
      -- `L.eval stmt.target.1 (-stmt.target.2)`. They differ only in
      -- the final product: raw is `∏_{j : Fin stmt.k} L(stmt.bases j)`,
      -- distinct is `∏_{i : Fin baseImageCount} L(baseAt i)`.
      -- These products share zero/nonzero status because
      -- `{stmt.bases j | j : Fin stmt.k} = {baseAt i | i : Fin baseImageCount}`
      -- (set-equality of images, with multiplicity collapsed on the
      -- distinct side but the value set is the same).
      intro hRawEqZero
      apply hDefDistinct
      -- Strategy: show that raw_denom = 0 implies distinct_denom = 0.
      -- Split raw_denom = common * ∏_{Fin stmt.k} L(stmt.bases j) = 0
      -- into: common = 0 (then distinct_denom shares `common = 0`) or
      -- one `L(stmt.bases j) = 0` (then `L(baseAt (baseIndexOf (finCongr hkm j))) = 0`,
      -- so the distinct product is 0).
      set common := msg.toD.eval A₀.1 A₀.2 * msg.toD.eval A₁.1 A₁.2 *
        msg.toD.eval (slopeOf A₀.1 A₀.2 A₁.1 A₁.2 ^ 2 - A₀.1 - A₁.1)
          (slopeOf A₀.1 A₀.2 A₁.1 A₁.2 *
            (slopeOf A₀.1 A₀.2 A₁.1 A₁.2 ^ 2 - A₀.1 - A₁.1) +
              (A₀.2 - slopeOf A₀.1 A₀.2 A₁.1 A₁.2 * A₀.1)) *
        (3 * A₀.1 ^ 2 + E.curveA - 2 * slopeOf A₀.1 A₀.2 A₁.1 A₁.2 * A₀.2) *
        (3 * A₁.1 ^ 2 + E.curveA -
          2 * slopeOf A₀.1 A₀.2 A₁.1 A₁.2 * A₁.2) *
        (3 * (slopeOf A₀.1 A₀.2 A₁.1 A₁.2 ^ 2 - A₀.1 - A₁.1) ^ 2 + E.curveA -
          2 * slopeOf A₀.1 A₀.2 A₁.1 A₁.2 *
            (slopeOf A₀.1 A₀.2 A₁.1 A₁.2 *
              (slopeOf A₀.1 A₀.2 A₁.1 A₁.2 ^ 2 - A₀.1 - A₁.1) +
              (A₀.2 - slopeOf A₀.1 A₀.2 A₁.1 A₁.2 * A₀.1))) *
        (lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval stmt.target.1 (-stmt.target.2)
      change common * ∏ j : Fin stmt.k,
        (lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
          (stmt.bases j).1 (stmt.bases j).2 = 0 at hRawEqZero
      change common * ∏ i : Fin (baseImageCount E stmt msg hkm),
        (lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval
          (baseAt E stmt msg hkm i).1 (baseAt E stmt msg hkm i).2 = 0
      rcases mul_eq_zero.mp hRawEqZero with hCommon | hProd
      · exact mul_eq_zero.mpr (Or.inl hCommon)
      · rw [Finset.prod_eq_zero_iff] at hProd
        obtain ⟨j, _, hj⟩ := hProd
        apply mul_eq_zero.mpr; right
        rw [Finset.prod_eq_zero_iff]
        refine ⟨baseIndexOf E stmt msg hkm (finCongr hkm j),
                Finset.mem_univ _, ?_⟩
        rw [baseAt_baseIndexOf]
        -- `extractorBases (finCongr hkm j) = stmt.bases j`.
        have hEq : extractorBases E stmt msg hkm (finCongr hkm j) = stmt.bases j := by
          unfold extractorBases
          congr 1
        rw [hEq]
        exact hj
    have hRaw := hAllZero A₀ A₁ hA₀ hA₁ hNV hDefRaw
    rw [logDerivCheckFn_eq_grouped] at hRaw
    exact hRaw
  -- Apply narrow bridge theorem (formerly the transient axiom, now a
  -- theorem taking the scalar `hPolyGZero` hypothesis).
  -- The conclusion uses `Fin.cons (P.1,-P.2) baseAt` and
  -- `Fin.cons (-1) (fun j => -distinctM'_tail j)`, which definitionally
  -- equal `distinctRCons` and `distinctMCons` (the latter has a
  -- negated tail per Session 41 sign resolution).
  exact polyG_zero_of_logDerivCheck_identically_zero E
    msg.toD hD stmt.target (baseImageCount E stmt msg hkm)
    (baseAt E stmt msg hkm) (distinctM'_tail E stmt msg hkm) hAllZero'
    Q beta hQinj hQzeros hQcov hβPos hβSum hPolyGZeroCons
    A₀ A₁ hA₀ hA₁ hNV

/-- Reindexing lemma: `polyG` is invariant under reindexing the `(R, m)`
    family by a bijection. Used to convert between the `Fin.cons` form
    (length `baseImageCount + 1`) and the `finCongr`-composed form
    (length `1 + baseImageCount`) used in T5. -/
theorem polyG_reindex
    {d M M' : ℕ}
    (Q : Fin d → ZMod E.q × ZMod E.q) (β : Fin d → ZMod E.q)
    (R : Fin M → ZMod E.q × ZMod E.q) (m : Fin M → ZMod E.q)
    (e : Fin M' ≃ Fin M)
    (A₀ A₁ : ZMod E.q × ZMod E.q) :
    polyG E Q β (R ∘ e) (m ∘ e) A₀ A₁ = polyG E Q β R m A₀ A₁ := by
  classical
  unfold polyG
  congr 1
  · -- First sum: β_k part. `R`-dependence is `∏_j ellP (R j)`, invariant
    -- under outer reindex.
    apply Finset.sum_congr rfl
    intro k _
    congr 1
    exact Equiv.prod_comp e (fun j => ellP E (R j) A₀ A₁)
  · -- Second sum: reindex outer sum; inner `erase` product shifts by `e`.
    rw [← Equiv.sum_comp e
      (fun j => m j *
        (Finset.univ.prod (fun k => ellP E (Q k) A₀ A₁)) *
        ((Finset.univ.erase j).prod (fun j' => ellP E (R j') A₀ A₁)))]
    apply Finset.sum_congr rfl
    intro j _
    show (m ∘ e) j * _ * _ = m (e j) * _ * _
    congr 1
    -- Inner erase-prod over `(R ∘ e)` at `univ.erase j` equals
    -- erase-prod over `R` at `univ.erase (e j)`.
    rw [show ((Finset.univ : Finset (Fin M')).erase j).prod
              (fun j' => ellP E ((R ∘ e) j') A₀ A₁)
           = ((Finset.univ : Finset (Fin M')).erase j).prod
              (fun j' => ellP E (R (e j')) A₀ A₁) from rfl]
    rw [← Finset.prod_image (g := (e : Fin M' → Fin M))
          (f := fun j' => ellP E (R j') A₀ A₁)
          (fun _ _ _ _ h => e.injective h)]
    congr 1
    rw [Finset.image_erase e.injective Finset.univ j,
        Finset.image_univ_equiv]

/-- **Main theorem (S3 — `distinctR` / `distinctM'` form)**: `polyG`
    vanishes on non-vertical `E × E` pairs with the distinct-base
    enumeration. Derived from `polyG_distinct_zero_cons` via
    `polyG_reindex`. -/
theorem polyG_distinct_zero_of_logDerivCheck_identically_zero
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q)
    (hkm : stmt.k = msg.k)
    (_hD : ¬ msg.toD.isZero)
    (_hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ →
      logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
        (fun i => msg.m (hkm ▸ i)) A₀ A₁ = 0)
    {d : ℕ}
    (Q : Fin d → ZMod E.q × ZMod E.q)
    (beta : Fin d → ℕ)
    (_hQinj : Function.Injective Q)
    (_hQzeros : ∀ k' : Fin d,
       Q k' ∈ E.points ∧ msg.toD.eval (Q k').1 (Q k').2 = 0)
    (_hQcov : ∀ Q' ∈ E.points, msg.toD.eval Q'.1 Q'.2 = 0 →
       ∃ k' : Fin d, Q k' = Q')
    (_hβPos : ∀ k', beta k' > 0)
    (_hβSum : (∑ k' : Fin d, beta k') = msg.toD.degE)
    (hPolyGZero :
      ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
        A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
        polyG E Q (fun k' => ((beta k' : ℕ) : ZMod E.q))
                  (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
                  A₀ A₁ = 0)
    (A₀ A₁ : ZMod E.q × ZMod E.q)
    (hA₀ : A₀ ∈ E.points) (hA₁ : A₁ ∈ E.points) (hNV : A₀.1 ≠ A₁.1) :
    polyG E Q (fun k' => ((beta k' : ℕ) : ZMod E.q))
              (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
              A₀ A₁ = 0 :=
  hPolyGZero A₀ A₁ hA₀ hA₁ hNV

/-! ## S4: T5 application — `σ`-matching existence

    Combine `CoordRingElt.has_principal_divisor` (Silverman III.3.5,
    providing the nonnegative multiplicity function `β_fun` for `D`'s
    affine zeros), the S3 raw→distinct polyG bridge
    (`polyG_distinct_zero_of_logDerivCheck_identically_zero`), and T5
    (`log_deriv_nonvanishing_criterion`) to produce the embedding
    `σ : Fin (zerosCard E D) ↪ Fin (1 + baseImageCount E stmt msg hkm)`
    matching each `D`-zero to a distinct-base index with the
    β-plus-m-sum-zero property, plus the complementary `m = 0` outside
    range(σ). The quantitative hypothesis of T5 is discharged directly
    from the hypothesis `hValidPairsLarge` (S7 will derive this from a
    cleaner `E.q`-vs-`(d + stmt.k + 1)` inequality via Hasse-Weil and
    `card_validPairs_lb`).
-/

/-- **S4 — distinct-σ existence.** The combined T5 + S3 + Silverman
    application: given `hAllZero` (raw `logDerivCheckFn ≡ 0`), the
    no-`-P`-in-bases assumption `hNoNegP`, nonzero-`D` hypothesis, and
    a quantitative bound `hValidPairsLarge`, produce:
    * `β_fun : ZMod² → ℕ` — principal-divisor multiplicities for `D`.
    * Its principal-divisor package (support, coverage, degree-sum,
      `dCoeffs`-principality).
    * An embedding `σ : Fin (zerosCard E D) ↪ Fin (1 + baseImageCount)`
      matching `zerosAt` to `distinctR`.
    * `(multAt k : ZMod E.q) + distinctM' (σ k) = 0` (β_k + m at σ k).
    * `distinctM' j = 0` for `j ∉ range σ`.

    Consumed by S5 (coefficient construction) + S6 (principality
    transfer) + S7 (final T4-bridge replacement). -/
theorem distinctSigma_exists
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hDeg : msg.toD.degE ≤ d) (hd : d < E.q) (hkm : stmt.k = msg.k)
    (hAdm : stmt.admSet (msg.polyA, msg.polyB))
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (_hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ →
      logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
        (fun i => msg.m (hkm ▸ i)) A₀ A₁ = 0)
    (hPolyGZero :
      ∀ (β_fun : ZMod E.q × ZMod E.q → ℕ),
        (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0) →
        (∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) →
        ((∑ P ∈ E.points, β_fun P) = msg.toD.degE) →
        ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
          A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
          polyG E (zerosAt E msg.toD)
            (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
            (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
            A₀ A₁ = 0)
    (hValidPairsLarge :
      6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) + 1
        ≤ (validPairs E).card) :
    ∃ (β_fun : ZMod E.q × ZMod E.q → ℕ)
      (σ : Fin (zerosCard E msg.toD) ↪
            Fin (1 + baseImageCount E stmt msg hkm)),
      (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0) ∧
      (∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) ∧
      ((∑ P ∈ E.points, β_fun P) = msg.toD.degE) ∧
      IsPrincipal E (dCoeffs E msg.toD β_fun) ∧
      (∀ k, zerosAt E msg.toD k = distinctR E stmt msg hkm (σ k)) ∧
      (∀ k, ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q)
            + distinctM' E stmt msg hkm (σ k) = 0) ∧
      (∀ j, j ∉ Set.range σ → distinctM' E stmt msg hkm j = 0) := by
  classical
  -- Step 1: nonzero-D hypothesis for `has_principal_divisor`.
  have hD : ¬ msg.toD.isZero := admSet_implies_toD_nonzero stmt msg hAdm
  -- Step 2: extract `β_fun` via Silverman III.3.5.
  obtain ⟨β_fun, hβsup, hβcov, hβsum, hβprincipal⟩ :=
    CoordRingElt.exists_principal_dCoeffs E msg.toD hD
  -- Step 3: build the `Q` / `beta_nat` pair for the distinct-polyG bridge.
  have hQinj : Function.Injective (zerosAt E msg.toD) :=
    zerosAt_injective E msg.toD
  have _hQzeros : ∀ k : Fin (zerosCard E msg.toD),
      zerosAt E msg.toD k ∈ E.points ∧
      msg.toD.eval (zerosAt E msg.toD k).1 (zerosAt E msg.toD k).2 = 0 :=
    fun k => ⟨zerosAt_mem_E E msg.toD k, zerosAt_eval_zero E msg.toD k⟩
  have _hQcov : ∀ Q' ∈ E.points, msg.toD.eval Q'.1 Q'.2 = 0 →
      ∃ k, zerosAt E msg.toD k = Q' := fun Q' hQ'pts hQ'zero =>
    zerosAt_covers_zeros E msg.toD Q' hQ'pts hQ'zero
  have hβPos : ∀ k : Fin (zerosCard E msg.toD),
                 multAt E β_fun msg.toD k > 0 :=
    multAt_pos E β_fun msg.toD hβcov
  have hβSum : (∑ k : Fin (zerosCard E msg.toD),
                   multAt E β_fun msg.toD k) = msg.toD.degE :=
    sum_multAt_eq_degE E β_fun msg.toD hβsup hβsum
  -- Step 4: each `multAt k` is strictly less than E.q (upper bound comes
  -- from `multAt k ≤ Σ multAt = D.degE ≤ d < E.q`).
  have hBetaLt : ∀ k, multAt E β_fun msg.toD k < E.q := by
    intro k
    have hSingle : multAt E β_fun msg.toD k ≤
        ∑ k' : Fin (zerosCard E msg.toD), multAt E β_fun msg.toD k' := by
      refine Finset.single_le_sum
        (f := fun k' => multAt E β_fun msg.toD k') ?_ (Finset.mem_univ k)
      intro k' _
      exact Nat.zero_le _
    rw [hβSum] at hSingle
    exact lt_of_le_of_lt (hSingle.trans hDeg) hd
  -- Step 5: `polyG` vanishes on non-vertical `E × E` in distinct form.
  have hPolyGZero' :
      ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
        A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
        polyG E (zerosAt E msg.toD)
          (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
          (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
          A₀ A₁ = 0 := hPolyGZero β_fun hβsup hβcov hβsum
  -- Step 6: set up T5's quantitative hypothesis.
  -- `zerosCard E msg.toD ≤ d`: each multiplicity ≥ 1, sum = D.degE ≤ d.
  have hd_zero_le_d : zerosCard E msg.toD ≤ d := by
    have hCardLe : zerosCard E msg.toD ≤
        ∑ k : Fin (zerosCard E msg.toD), multAt E β_fun msg.toD k := by
      calc zerosCard E msg.toD
          = ∑ _k : Fin (zerosCard E msg.toD), 1 := by
              simp [Finset.sum_const, Finset.card_univ, Fintype.card_fin]
        _ ≤ ∑ k : Fin (zerosCard E msg.toD), multAt E β_fun msg.toD k :=
              Finset.sum_le_sum (fun k _ => hβPos k)
    exact hCardLe.trans (hβSum.le.trans hDeg)
  -- `baseImageCount ≤ msg.k = stmt.k`.
  have hBICount_le : baseImageCount E stmt msg hkm ≤ stmt.k := by
    have hleK : baseImageCount E stmt msg hkm ≤ msg.k := by
      unfold baseImageCount baseImage
      refine (Finset.card_image_le (f := extractorBases E stmt msg hkm)
                 (s := Finset.univ)).trans ?_
      rw [Finset.card_univ, Fintype.card_fin]
    rw [hkm]; exact hleK
  have hSum_le :
      zerosCard E msg.toD + (1 + baseImageCount E stmt msg hkm)
        ≤ d + stmt.k + 1 := by
    have : zerosCard E msg.toD + (1 + baseImageCount E stmt msg hkm)
            ≤ d + (1 + stmt.k) :=
      Nat.add_le_add hd_zero_le_d (Nat.add_le_add_left hBICount_le _)
    omega
  have hQuant : 6 * E.q * ((zerosCard E msg.toD
                              + (1 + baseImageCount E stmt msg hkm))
                  + (zerosCard E msg.toD
                      + (1 + baseImageCount E stmt msg hkm))
                     * (zerosCard E msg.toD
                          + (1 + baseImageCount E stmt msg hkm) - 1)) + 1
                ≤ (validPairs E).card := by
    refine le_trans ?_ hValidPairsLarge
    apply Nat.add_le_add_right
    apply Nat.mul_le_mul_left
    apply Nat.add_le_add hSum_le
    have hSub_le :
        zerosCard E msg.toD + (1 + baseImageCount E stmt msg hkm) - 1
          ≤ d + stmt.k := by
      have := Nat.sub_le_sub_right hSum_le 1
      have hEq : d + stmt.k + 1 - 1 = d + stmt.k := by omega
      rw [hEq] at this; exact this
    exact Nat.mul_le_mul hSum_le hSub_le
  -- Step 7: `hBetaNz` — each `multAt k` cast to `ZMod E.q` is nonzero.
  have hBetaNz : ∀ k,
      ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q) ≠ 0 := by
    intro k
    rw [Ne, CharP.cast_eq_zero_iff (ZMod E.q) E.q]
    intro hdvd
    have hPos : 0 < multAt E β_fun msg.toD k := hβPos k
    have hLt : multAt E β_fun msg.toD k < E.q := hBetaLt k
    exact Nat.not_lt.mpr (Nat.le_of_dvd hPos hdvd) hLt
  -- Step 8: apply T5.
  have hDistinctR_inj : Function.Injective (distinctR E stmt msg hkm) :=
    distinctR_injective E stmt msg hkm hNoNegP
  obtain ⟨σ, hσ_eq, hσ_betam, hσ_off⟩ :=
    log_deriv_nonvanishing_criterion E (zerosAt E msg.toD)
      (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
      (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
      hQuant hQinj hDistinctR_inj hBetaNz hPolyGZero'
  -- Step 9: package the output.
  exact ⟨β_fun, σ, hβsup, hβcov, hβsum, hβprincipal,
         hσ_eq, hσ_betam, hσ_off⟩

/-! ## S5: extractor coefficient function from σ

    Given the `σ`-matching output of `distinctSigma_exists`, build a
    natural-number coefficient `Fin msg.k → ℕ` whose ZMod residues match
    `-extractorGroupSum` at canonical indices (and zero elsewhere), with
    the D3 bound `coeff i < d`. Feeds into
    `extractorSucceeds_of_natural_witness` (D3) to produce the full
    `extractorSucceeds ∧ extractedScalars i = coeff i` package.

    Structure:
    * `baseImagePos` — position in `distinctR` corresponding to a
      `baseIndexOf i` canonical index.
    * `extractorCoeffFromSigma` — the coefficient function.
    * `sigma_zero_preimage_exists` — σ must hit position `0` (else
      `distinctM' 0 = -1 = 0`, contradiction).
    * `extractorCoeffFromSigma_satisfies_D3` — main S5 theorem: the
      three hypotheses of `extractorSucceeds_of_natural_witness` hold.
-/

/-- Position in `distinctR` corresponding to a distinct-base index.
    Shape `⟨i.val + 1, _⟩` to match `distinctR_succ`. -/
noncomputable def baseImagePos
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i : Fin (baseImageCount E stmt msg hkm)) :
    Fin (1 + baseImageCount E stmt msg hkm) :=
  ⟨i.val + 1, by omega⟩

theorem baseImagePos_val
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i : Fin (baseImageCount E stmt msg hkm)) :
    (baseImagePos E stmt msg hkm i).val = i.val + 1 := rfl

theorem baseImagePos_ne_zero
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i : Fin (baseImageCount E stmt msg hkm)) :
    baseImagePos E stmt msg hkm i
      ≠ (⟨0, by omega⟩ : Fin (1 + baseImageCount E stmt msg hkm)) := by
  intro h
  have : (baseImagePos E stmt msg hkm i).val = 0 := by rw [h]
  rw [baseImagePos_val] at this
  omega

@[simp] theorem distinctR_baseImagePos
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctR E stmt msg hkm (baseImagePos E stmt msg hkm i)
      = baseAt E stmt msg hkm i :=
  distinctR_succ E stmt msg hkm i

@[simp] theorem distinctM'_baseImagePos
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (i : Fin (baseImageCount E stmt msg hkm)) :
    distinctM' E stmt msg hkm (baseImagePos E stmt msg hkm i)
      = -extractorGroupSum E stmt msg hkm
          (baseAtIndex E stmt msg hkm i) :=
  distinctM'_succ E stmt msg hkm i

/-- **Extractor coefficient function from σ.** At canonical `i`, if the
    distinct-R position corresponding to `extractorBases i` is hit by σ
    at some `k`, return `multAt k`; else `0`. At non-canonical `i`,
    return `0`. -/
noncomputable def extractorCoeffFromSigma
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (β_fun : ZMod E.q × ZMod E.q → ℕ)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm)) :
    Fin msg.k → ℕ := fun i =>
  if extractorIsCanonical E stmt msg hkm i then
    if hHit : ∃ k : Fin (zerosCard E msg.toD),
        σ k = baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i) then
      multAt E β_fun msg.toD hHit.choose
    else 0
  else 0

theorem extractorCoeffFromSigma_noncanon
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (β_fun : ZMod E.q × ZMod E.q → ℕ)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm))
    (i : Fin msg.k) (hNotCanon : ¬ extractorIsCanonical E stmt msg hkm i) :
    extractorCoeffFromSigma E stmt msg hkm β_fun σ i = 0 := by
  unfold extractorCoeffFromSigma
  rw [if_neg hNotCanon]

theorem extractorCoeffFromSigma_canonical_hit
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (β_fun : ZMod E.q × ZMod E.q → ℕ)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm))
    (i : Fin msg.k) (hCanon : extractorIsCanonical E stmt msg hkm i)
    (hHit : ∃ k : Fin (zerosCard E msg.toD),
        σ k = baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i)) :
    extractorCoeffFromSigma E stmt msg hkm β_fun σ i
      = multAt E β_fun msg.toD hHit.choose := by
  unfold extractorCoeffFromSigma
  rw [if_pos hCanon, dif_pos hHit]

theorem extractorCoeffFromSigma_canonical_nohit
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (β_fun : ZMod E.q × ZMod E.q → ℕ)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm))
    (i : Fin msg.k) (hCanon : extractorIsCanonical E stmt msg hkm i)
    (hNoHit : ¬ ∃ k : Fin (zerosCard E msg.toD),
        σ k = baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i)) :
    extractorCoeffFromSigma E stmt msg hkm β_fun σ i = 0 := by
  unfold extractorCoeffFromSigma
  rw [if_pos hCanon, dif_neg hNoHit]

/-- **σ must hit position 0.** From the σ-output's off-range condition:
    `j ∉ range σ → distinctM' j = 0`. Applied at `j = 0`, we would get
    `distinctM' 0 = 0`, but `distinctM' 0 = -1 ≠ 0` in `ZMod E.q` (since
    `E.q ≥ 5 ≥ 2` is prime). Hence `0 ∈ range σ`. -/
theorem sigma_zero_preimage_exists
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm))
    (hσ_off : ∀ j, j ∉ Set.range σ → distinctM' E stmt msg hkm j = 0) :
    ∃ k₀ : Fin (zerosCard E msg.toD),
      σ k₀ = (⟨0, by omega⟩ : Fin (1 + baseImageCount E stmt msg hkm)) := by
  classical
  by_contra hne
  push_neg at hne
  have h0notRange :
      (⟨0, by omega⟩ : Fin (1 + baseImageCount E stmt msg hkm))
        ∉ Set.range σ := by
    intro hRange
    obtain ⟨k, hk⟩ := hRange
    exact hne k hk
  have h0m : distinctM' E stmt msg hkm
      (⟨0, by omega⟩ : Fin (1 + baseImageCount E stmt msg hkm)) = 0 :=
    hσ_off _ h0notRange
  rw [distinctM'_zero] at h0m
  -- Now h0m : (-1 : ZMod E.q) = 0, contradicts one_ne_zero (via neg_eq_zero).
  have h1 : (1 : ZMod E.q) = 0 := neg_eq_zero.mp h0m
  exact one_ne_zero h1

/-- **Bound for the multiplicity at σ's zero-preimage.** `multAt k₀ ≥ 1`
    where `k₀` is the (any) index with `σ k₀ = 0`. Follows from
    `multAt_pos` (every `multAt k` is positive under the `β`-coverage
    condition). -/
theorem multAt_at_sigma_zero_pos
    (β_fun : ZMod E.q × ZMod E.q → ℕ) (D : CoordRingElt E.q)
    (hβcov : ∀ P ∈ E.points, D.eval P.1 P.2 = 0 → β_fun P ≠ 0)
    (k₀ : Fin (zerosCard E D)) :
    1 ≤ multAt E β_fun D k₀ :=
  multAt_pos E β_fun D hβcov k₀

/-- **Bound lemma.** For `k ≠ k₀` in `Fin (zerosCard E D)`,
    `multAt k ≤ D.degE - 1`. Uses `multAt k + multAt k₀ ≤ ∑ multAt = D.degE`
    with `multAt k₀ ≥ 1`. -/
theorem multAt_le_degE_sub_one_of_ne
    (β_fun : ZMod E.q × ZMod E.q → ℕ) (D : CoordRingElt E.q)
    (hβsup : ∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ D.eval P.1 P.2 = 0)
    (hβsum : (∑ P ∈ E.points, β_fun P) = D.degE)
    (hβcov : ∀ P ∈ E.points, D.eval P.1 P.2 = 0 → β_fun P ≠ 0)
    {k k₀ : Fin (zerosCard E D)} (hne : k ≠ k₀) :
    multAt E β_fun D k + 1 ≤ D.degE := by
  classical
  have hSum := sum_multAt_eq_degE E β_fun D hβsup hβsum
  -- Insert: sum over {k, k₀} ≤ sum over univ.
  have hPair : multAt E β_fun D k + multAt E β_fun D k₀ ≤
               ∑ k' : Fin (zerosCard E D), multAt E β_fun D k' := by
    have hSubset : ({k, k₀} : Finset (Fin (zerosCard E D))) ⊆ Finset.univ := by
      intro x _; exact Finset.mem_univ _
    have hSumPair :
        ∑ k' ∈ ({k, k₀} : Finset (Fin (zerosCard E D))),
            multAt E β_fun D k'
          = multAt E β_fun D k + multAt E β_fun D k₀ := by
      rw [Finset.sum_insert (by
        simp only [Finset.mem_singleton]
        exact hne), Finset.sum_singleton]
    rw [← hSumPair]
    exact Finset.sum_le_sum_of_subset_of_nonneg hSubset
      (fun _ _ _ => Nat.zero_le _)
  have hk₀ : 1 ≤ multAt E β_fun D k₀ := multAt_at_sigma_zero_pos E β_fun D hβcov k₀
  omega

/-- **Main S5 theorem.** `extractorCoeffFromSigma` satisfies the three
    hypotheses of `extractorSucceeds_of_natural_witness` (D3). Combined
    with `distinctSigma_exists` (S4) and `extractorSucceeds_of_natural_witness`
    (D3), this produces the `extractorSucceeds` + `extractedScalars =
    coeff` package that S7 needs. -/
theorem extractorCoeffFromSigma_satisfies_D3
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hDeg : msg.toD.degE ≤ d) (hkm : stmt.k = msg.k)
    (_hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (β_fun : ZMod E.q × ZMod E.q → ℕ)
    (hβsup : ∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0)
    (hβcov : ∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0)
    (hβsum : (∑ P ∈ E.points, β_fun P) = msg.toD.degE)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm))
    (_hσ_eq : ∀ k, zerosAt E msg.toD k = distinctR E stmt msg hkm (σ k))
    (hσ_betam : ∀ k,
      ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q)
        + distinctM' E stmt msg hkm (σ k) = 0)
    (hσ_off : ∀ j, j ∉ Set.range σ → distinctM' E stmt msg hkm j = 0) :
    (∀ i, extractorCoeffFromSigma E stmt msg hkm β_fun σ i < d) ∧
    (∀ i, extractorIsCanonical E stmt msg hkm i →
      (extractorCoeffFromSigma E stmt msg hkm β_fun σ i : ZMod E.q)
        = extractorGroupSum E stmt msg hkm i) ∧
    (∀ i, ¬ extractorIsCanonical E stmt msg hkm i →
      extractorCoeffFromSigma E stmt msg hkm β_fun σ i = 0) := by
  classical
  -- k₀ is the preimage of 0 under σ.
  obtain ⟨k₀, hk₀⟩ := sigma_zero_preimage_exists E stmt msg hkm σ hσ_off
  refine ⟨?_, ?_, ?_⟩
  -- (1) Bound: extractorCoeffFromSigma i < d.
  · intro i
    by_cases hC : extractorIsCanonical E stmt msg hkm i
    · by_cases hHit : ∃ k : Fin (zerosCard E msg.toD),
          σ k = baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i)
      · rw [extractorCoeffFromSigma_canonical_hit E stmt msg hkm β_fun σ i hC hHit]
        -- Use hHit.choose: σ (hHit.choose) = pos_i ≠ 0 = σ k₀, so
        -- hHit.choose ≠ k₀. Hence multAt (hHit.choose) ≤ D.degE - 1 ≤ d - 1 < d.
        set k := hHit.choose
        have hkspec : σ k = baseImagePos E stmt msg hkm
            (baseIndexOf E stmt msg hkm i) := hHit.choose_spec
        have hkne_k₀ : k ≠ k₀ := by
          intro hEq
          rw [hEq] at hkspec
          rw [hk₀] at hkspec
          exact baseImagePos_ne_zero E stmt msg hkm (baseIndexOf E stmt msg hkm i)
            hkspec.symm
        have hBound : multAt E β_fun msg.toD k + 1 ≤ msg.toD.degE :=
          multAt_le_degE_sub_one_of_ne E β_fun msg.toD
            hβsup hβsum hβcov hkne_k₀
        have : multAt E β_fun msg.toD k + 1 ≤ d :=
          hBound.trans hDeg
        omega
      · rw [extractorCoeffFromSigma_canonical_nohit
              E stmt msg hkm β_fun σ i hC hHit]
        -- Need: 0 < d. Use multAt_at_sigma_zero_pos + hβsum + hDeg.
        have hk₀_pos : 1 ≤ multAt E β_fun msg.toD k₀ :=
          multAt_at_sigma_zero_pos E β_fun msg.toD hβcov k₀
        -- 1 ≤ multAt k₀ ≤ ∑ multAt = D.degE ≤ d.
        have hSum := sum_multAt_eq_degE E β_fun msg.toD hβsup hβsum
        have hSingle : multAt E β_fun msg.toD k₀ ≤
            ∑ k' : Fin (zerosCard E msg.toD), multAt E β_fun msg.toD k' := by
          refine Finset.single_le_sum
            (f := fun k' => multAt E β_fun msg.toD k') ?_ (Finset.mem_univ k₀)
          intro _ _; exact Nat.zero_le _
        rw [hSum] at hSingle
        omega
    · rw [extractorCoeffFromSigma_noncanon E stmt msg hkm β_fun σ i hC]
      -- Same 0 < d argument.
      have hk₀_pos : 1 ≤ multAt E β_fun msg.toD k₀ :=
        multAt_at_sigma_zero_pos E β_fun msg.toD hβcov k₀
      have hSum := sum_multAt_eq_degE E β_fun msg.toD hβsup hβsum
      have hSingle : multAt E β_fun msg.toD k₀ ≤
          ∑ k' : Fin (zerosCard E msg.toD), multAt E β_fun msg.toD k' := by
        refine Finset.single_le_sum
          (f := fun k' => multAt E β_fun msg.toD k') ?_ (Finset.mem_univ k₀)
        intro _ _; exact Nat.zero_le _
      rw [hSum] at hSingle
      omega
  -- (2) ZMod identity at canonical i.
  · intro i hC
    by_cases hHit : ∃ k : Fin (zerosCard E msg.toD),
        σ k = baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i)
    · rw [extractorCoeffFromSigma_canonical_hit
            E stmt msg hkm β_fun σ i hC hHit]
      set k := hHit.choose
      have hkspec : σ k = baseImagePos E stmt msg hkm
          (baseIndexOf E stmt msg hkm i) := hHit.choose_spec
      -- multAt k + distinctM' (σ k) = 0 ⇒ multAt k = -distinctM' (σ k).
      have hBetaM := hσ_betam k
      -- distinctM' (σ k) = distinctM' baseImagePos = extractorGroupSum (baseAtIndex (baseIndexOf i))
      --                   = extractorGroupSum i (since extractorBases (baseAtIndex (baseIndexOf i)) = baseAt (baseIndexOf i) = extractorBases i).
      rw [hkspec, distinctM'_baseImagePos] at hBetaM
      -- Translate extractorGroupSum (baseAtIndex (baseIndexOf i)) = extractorGroupSum i.
      have hBases_eq : extractorBases E stmt msg hkm
          (baseAtIndex E stmt msg hkm (baseIndexOf E stmt msg hkm i))
            = extractorBases E stmt msg hkm i := by
        rw [baseAtIndex_spec E stmt msg hkm (baseIndexOf E stmt msg hkm i),
            baseAt_baseIndexOf]
      have hGroupSum_eq :
          extractorGroupSum E stmt msg hkm
            (baseAtIndex E stmt msg hkm (baseIndexOf E stmt msg hkm i))
            = extractorGroupSum E stmt msg hkm i :=
        extractorGroupSum_congr_of_extractorBases_eq E stmt msg hkm hBases_eq
      rw [hGroupSum_eq] at hBetaM
      -- hBetaM : (multAt k : ZMod q) + (-extractorGroupSum i) = 0
      -- (post Session 41 sign: distinctM'_baseImagePos is NEGATED).
      -- Goal: (multAt k : ZMod q) = extractorGroupSum i.
      linear_combination hBetaM
    · rw [extractorCoeffFromSigma_canonical_nohit
            E stmt msg hkm β_fun σ i hC hHit]
      -- pos_i ∉ range σ ⇒ distinctM' pos_i = 0 ⇒ extractorGroupSum i = 0.
      push_neg at hHit
      have hPosNotRange :
          baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i)
            ∉ Set.range σ := by
        intro hInRange
        obtain ⟨k, hk⟩ := hInRange
        exact hHit k hk
      have hM : distinctM' E stmt msg hkm
          (baseImagePos E stmt msg hkm (baseIndexOf E stmt msg hkm i)) = 0 :=
        hσ_off _ hPosNotRange
      rw [distinctM'_baseImagePos] at hM
      -- hM : extractorGroupSum (baseAtIndex (baseIndexOf i)) = 0
      -- translate to extractorGroupSum i.
      have hBases_eq : extractorBases E stmt msg hkm
          (baseAtIndex E stmt msg hkm (baseIndexOf E stmt msg hkm i))
            = extractorBases E stmt msg hkm i := by
        rw [baseAtIndex_spec E stmt msg hkm (baseIndexOf E stmt msg hkm i),
            baseAt_baseIndexOf]
      have hGroupSum_eq :
          extractorGroupSum E stmt msg hkm
            (baseAtIndex E stmt msg hkm (baseIndexOf E stmt msg hkm i))
            = extractorGroupSum E stmt msg hkm i :=
        extractorGroupSum_congr_of_extractorBases_eq E stmt msg hkm hBases_eq
      rw [hGroupSum_eq] at hM
      -- hM : -extractorGroupSum i = 0 (post Session 41 sign).
      -- Goal: 0 = extractorGroupSum i.
      have hZero : extractorGroupSum E stmt msg hkm i = 0 := by
        linear_combination -hM
      simp [hZero]
  -- (3) Non-canonical indices: trivial.
  · intro i hNotCanon
    exact extractorCoeffFromSigma_noncanon E stmt msg hkm β_fun σ i hNotCanon

/-! ## S6: extractorDivisorCoeffs ↔ dCoeffs matching

    Pointwise equality `extractorDivisorCoeffs = dCoeffs E msg.toD β_fun`
    on `ECPoint E.q` under the σ-matching output of `distinctSigma_exists`.
    Combined with `distinctSigma_exists`'s `IsPrincipal (dCoeffs ...)`
    conclusion and `funext`, this yields
    `IsPrincipal E (extractorDivisorCoeffs E stmt msg hkm)`.

    The packaged theorem `extractor_succeeds_and_isPrincipal` combines
    S4 + S5 + S6 into the full composite conclusion
    `extractorSucceeds ∧ IsPrincipal (extractorDivisorCoeffs)`,
    as consumed by S7 to replace the former composite T4 bridge axiom.
-/

/-- **Helper: σ k is either 0 or `baseImagePos i`**.
    Every `j : Fin (1 + baseImageCount)` is either `⟨0, _⟩` or
    `⟨i.val + 1, _⟩` for some `i : Fin baseImageCount`. -/
theorem fin_one_plus_cases
    (n : ℕ) (j : Fin (1 + n)) :
    j = (⟨0, by omega⟩ : Fin (1 + n)) ∨
    ∃ i : Fin n, j = (⟨i.val + 1, by omega⟩ : Fin (1 + n)) := by
  rcases j with ⟨v, hv⟩
  rcases v with _ | v
  · left; rfl
  · right
    refine ⟨⟨v, by omega⟩, ?_⟩
    rfl

/-- **Helper**: at a non-canonical index `j`, filter selects the
    canonical representative so its `extractedScalars`-sum is at the
    canonical value (mirror of `sum_extractedScalars_over_group`). -/
theorem extractorDivisorCoeffs_affine_not_in_baseImage
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (hkm : stmt.k = msg.k)
    (x y : ZMod E.q)
    (hNot : (x, y) ∉ baseImage E stmt msg hkm) :
    ((Finset.univ : Finset (Fin msg.k)).filter
      (fun j => extractorBases E stmt msg hkm j = (x, y))) = ∅ := by
  classical
  rw [Finset.eq_empty_iff_forall_notMem]
  intro j hj
  simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj
  apply hNot
  refine Finset.mem_image.mpr ⟨j, Finset.mem_univ _, hj⟩

/-- **S6 — pointwise matching.** Under the σ-matching hypotheses
    produced by `distinctSigma_exists`, the extractor's divisor
    coefficient function equals `dCoeffs E msg.toD β_fun` at every
    point of `ECPoint E.q`.

    Combined with `IsPrincipal (dCoeffs ...)` from S4 and `funext`,
    this gives `IsPrincipal (extractorDivisorCoeffs ...)`. -/
theorem extractorDivisorCoeffs_eq_dCoeffs
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hDeg : msg.toD.degE ≤ d) (hd : d < E.q) (hkm : stmt.k = msg.k)
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (β_fun : ZMod E.q × ZMod E.q → ℕ)
    (hβsup : ∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0)
    (hβcov : ∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0)
    (hβsum : (∑ P ∈ E.points, β_fun P) = msg.toD.degE)
    (σ : Fin (zerosCard E msg.toD) ↪
          Fin (1 + baseImageCount E stmt msg hkm))
    (hσ_eq : ∀ k, zerosAt E msg.toD k = distinctR E stmt msg hkm (σ k))
    (hσ_betam : ∀ k,
      ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q)
        + distinctM' E stmt msg hkm (σ k) = 0)
    (hσ_off : ∀ j, j ∉ Set.range σ → distinctM' E stmt msg hkm j = 0)
    (P : ECPoint E.q) :
    extractorDivisorCoeffs E stmt msg hkm P = dCoeffs E msg.toD β_fun P := by
  classical
  -- D3 data for the σ-matching (S5).
  obtain ⟨hBound, hCanon, hNonCanon⟩ :=
    extractorCoeffFromSigma_satisfies_D3 E stmt msg d hDeg hkm hNoNegP β_fun
      hβsup hβcov hβsum σ hσ_eq hσ_betam hσ_off
  -- D3 consumption for extractedScalars.
  obtain ⟨_, hScalars_eq⟩ :=
    extractorSucceeds_of_natural_witness E stmt msg d hd hkm hNoNegP
      (extractorCoeffFromSigma E stmt msg hkm β_fun σ)
      hBound hCanon hNonCanon
  -- D-zeros enumeration: σ k₀ = 0 for some k₀.
  obtain ⟨k₀, hk₀⟩ := sigma_zero_preimage_exists E stmt msg hkm σ hσ_off
  -- multAt k₀ = 1 in ℕ (via ZMod q identity + bound multAt k₀ < E.q).
  have hBetaLt : ∀ k, multAt E β_fun msg.toD k < E.q := by
    intro k
    have hSingle : multAt E β_fun msg.toD k ≤
        ∑ k' : Fin (zerosCard E msg.toD), multAt E β_fun msg.toD k' := by
      refine Finset.single_le_sum
        (f := fun k' => multAt E β_fun msg.toD k') ?_ (Finset.mem_univ k)
      intro _ _; exact Nat.zero_le _
    have hSum := sum_multAt_eq_degE E β_fun msg.toD hβsup hβsum
    rw [hSum] at hSingle
    exact lt_of_le_of_lt (hSingle.trans hDeg) hd
  have hMult_k₀_one_nat : multAt E β_fun msg.toD k₀ = 1 := by
    have hBM := hσ_betam k₀
    rw [hk₀, distinctM'_zero] at hBM
    -- hBM : (multAt k₀ : ZMod E.q) + (-1) = 0 ⇒ (multAt k₀ : ZMod E.q) = 1.
    have hZMod : ((multAt E β_fun msg.toD k₀ : ℕ) : ZMod E.q) = 1 := by
      have : ((multAt E β_fun msg.toD k₀ : ℕ) : ZMod E.q) = 0 - (-1) := by
        linear_combination hBM
      rw [this]; ring
    -- Bound: multAt k₀ < E.q, and (multAt k₀ : ZMod q) = 1 with q ≥ 2.
    have h1LtQ : (1 : ℕ) < E.q := E.hq_prime.one_lt
    have h1ValEq : ((1 : ZMod E.q)).val = 1 := by
      rw [ZMod.val_one_eq_one_mod]
      exact Nat.mod_eq_of_lt h1LtQ
    have hValLeft : ((multAt E β_fun msg.toD k₀ : ℕ) : ZMod E.q).val =
        multAt E β_fun msg.toD k₀ :=
      ZMod.val_natCast_of_lt (hBetaLt k₀)
    rw [hZMod] at hValLeft
    rw [h1ValEq] at hValLeft
    exact hValLeft.symm
  -- zerosAt k₀ = -P_aff.
  have hk₀_aff : zerosAt E msg.toD k₀ = (stmt.target.1, -stmt.target.2) := by
    rw [hσ_eq k₀, hk₀, distinctR_zero]
  -- β_fun (-P_aff) = multAt k₀ = 1.
  have hβ_negP : β_fun (stmt.target.1, -stmt.target.2) = 1 := by
    have : β_fun (zerosAt E msg.toD k₀) = multAt E β_fun msg.toD k₀ := rfl
    rw [← hk₀_aff, this, hMult_k₀_one_nat]
  -- Case on P.
  cases P with
  | infinity =>
      show -(msg.toD.degE : ℤ) = -(msg.toD.degE : ℤ); rfl
  | affine x y =>
      -- LHS = indicator + filter-sum extractedScalars.
      -- RHS = (β_fun (x, y) : ℤ).
      show (if (x, y) = (stmt.target.1, -stmt.target.2)
            then (1 : ℤ) else 0) +
           ∑ j ∈ (Finset.univ : Finset (Fin msg.k)).filter
             (fun j => extractorBases E stmt msg hkm j = (x, y)),
             extractedScalars E stmt msg hkm j = (β_fun (x, y) : ℤ)
      by_cases hxy : (x, y) = (stmt.target.1, -stmt.target.2)
      · -- Sub-case: (x, y) = -P_aff.
        rw [if_pos hxy, hxy]
        -- The filter is empty by hNoNegP.
        have hEmpty : ((Finset.univ : Finset (Fin msg.k)).filter
            (fun j => extractorBases E stmt msg hkm j =
                       (stmt.target.1, -stmt.target.2))) = ∅ := by
          rw [Finset.eq_empty_iff_forall_notMem]
          intro j hj
          apply hNoNegP
          exact ⟨j, hj⟩
        rw [hEmpty, Finset.sum_empty, add_zero, hβ_negP]
        rfl
      · -- Sub-case: (x, y) ≠ -P_aff. Indicator = 0.
        rw [if_neg hxy, zero_add]
        by_cases hInImage : (x, y) ∈ baseImage E stmt msg hkm
        · -- Sub-sub-case: (x, y) ∈ baseImage.
          -- Let i_c = canonical index with extractorBases i_c = (x, y).
          rw [baseImage, Finset.mem_image] at hInImage
          obtain ⟨j₀, _, hj₀eq⟩ := hInImage
          -- Canonicalize: i_c = (extractorGroup j₀).min'.
          set i_c := (extractorGroup E stmt msg hkm j₀).min'
            (extractorGroup_nonempty E stmt msg hkm j₀) with hi_c_def
          have hi_c_canon : extractorIsCanonical E stmt msg hkm i_c := by
            show (extractorGroup E stmt msg hkm i_c).min'
              (extractorGroup_nonempty E stmt msg hkm i_c) = i_c
            have hi_c_in : i_c ∈ extractorGroup E stmt msg hkm j₀ :=
              Finset.min'_mem _ _
            have hG_eq : extractorGroup E stmt msg hkm i_c =
                         extractorGroup E stmt msg hkm j₀ :=
              extractedScalars_group_canonical E stmt msg hkm j₀ i_c hi_c_in
            apply le_antisymm
            · apply Finset.min'_le
              exact mem_extractorGroup_self E stmt msg hkm i_c
            · apply Finset.le_min'
              intro y' hy'
              rw [hG_eq] at hy'
              rw [hi_c_def]
              exact Finset.min'_le _ _ hy'
          -- extractorBases i_c = extractorBases j₀ = (x, y).
          have hi_c_base : extractorBases E stmt msg hkm i_c = (x, y) := by
            have hi_c_in : i_c ∈ extractorGroup E stmt msg hkm j₀ :=
              Finset.min'_mem _ _
            have := Finset.mem_filter.mp hi_c_in
            rw [this.2, hj₀eq]
          -- The filter sum equals extractedScalars i_c.
          -- Go via sum_extractedScalars_over_group.
          have hFilter_eq_group : ((Finset.univ : Finset (Fin msg.k)).filter
              (fun j => extractorBases E stmt msg hkm j = (x, y)))
              = extractorGroup E stmt msg hkm i_c := by
            ext j
            simp only [Finset.mem_filter, Finset.mem_univ, true_and,
              extractorGroup]
            rw [hi_c_base]
          have hSum_group : ∑ j ∈ extractorGroup E stmt msg hkm i_c,
              extractedScalars E stmt msg hkm j
              = extractedScalars E stmt msg hkm
                  ((extractorGroup E stmt msg hkm i_c).min'
                    (extractorGroup_nonempty E stmt msg hkm i_c)) :=
            sum_extractedScalars_over_group E stmt msg hkm hNoNegP i_c
          rw [hFilter_eq_group, hSum_group, hi_c_canon]
          -- extractedScalars i_c = (extractorCoeffFromSigma ... i_c : ℤ).
          rw [hScalars_eq i_c]
          -- Now case on whether σ hits baseImagePos (baseIndexOf i_c).
          set pos := baseImagePos E stmt msg hkm
            (baseIndexOf E stmt msg hkm i_c) with hpos_def
          by_cases hHit : ∃ k : Fin (zerosCard E msg.toD), σ k = pos
          · -- Hit: extractorCoeffFromSigma i_c = multAt (hHit.choose).
            rw [hpos_def] at hHit
            rw [extractorCoeffFromSigma_canonical_hit
                  E stmt msg hkm β_fun σ i_c hi_c_canon hHit]
            set k := hHit.choose
            have hkspec : σ k = baseImagePos E stmt msg hkm
                (baseIndexOf E stmt msg hkm i_c) := hHit.choose_spec
            -- zerosAt k = distinctR (σ k) = baseAt (baseIndexOf i_c) = extractorBases i_c = (x, y).
            have hzerosAt_k : zerosAt E msg.toD k = (x, y) := by
              rw [hσ_eq k, hkspec, distinctR_baseImagePos,
                  baseAt_baseIndexOf, hi_c_base]
            -- β_fun (x, y) = β_fun (zerosAt k) = multAt k.
            have hβ_xy : β_fun (x, y) = multAt E β_fun msg.toD k := by
              unfold multAt
              rw [hzerosAt_k]
            rw [hβ_xy]
          · -- No hit: extractorCoeffFromSigma i_c = 0. Need β_fun (x, y) = 0.
            rw [hpos_def] at hHit
            rw [extractorCoeffFromSigma_canonical_nohit
                  E stmt msg hkm β_fun σ i_c hi_c_canon hHit]
            -- Show β_fun (x, y) = 0 by contradiction with hβsup + zerosAt_covers_zeros.
            have hβ_eq_zero : β_fun (x, y) = 0 := by
              by_contra hβne
              obtain ⟨hMem, hEval⟩ := hβsup (x, y) hβne
              obtain ⟨k, hk⟩ := zerosAt_covers_zeros E msg.toD (x, y) hMem hEval
              -- distinctR (σ k) = zerosAt k = (x, y) = baseAt (baseIndexOf i_c) = distinctR pos.
              have hDRσ : distinctR E stmt msg hkm (σ k) = (x, y) := by
                rw [← hσ_eq k, hk]
              have hDRpos : distinctR E stmt msg hkm
                  (baseImagePos E stmt msg hkm
                    (baseIndexOf E stmt msg hkm i_c)) = (x, y) := by
                rw [distinctR_baseImagePos, baseAt_baseIndexOf, hi_c_base]
              have hEqDR : distinctR E stmt msg hkm (σ k) =
                  distinctR E stmt msg hkm
                    (baseImagePos E stmt msg hkm
                      (baseIndexOf E stmt msg hkm i_c)) := by
                rw [hDRσ, hDRpos]
              have hσk_eq_pos : σ k =
                  baseImagePos E stmt msg hkm
                    (baseIndexOf E stmt msg hkm i_c) :=
                distinctR_injective E stmt msg hkm hNoNegP hEqDR
              exact hHit ⟨k, hσk_eq_pos⟩
            rw [hβ_eq_zero]
        · -- Sub-sub-case: (x, y) ∉ baseImage.
          rw [extractorDivisorCoeffs_affine_not_in_baseImage E stmt msg hkm
                x y hInImage, Finset.sum_empty]
          -- β_fun (x, y) = 0 by contradiction.
          have hβ_eq_zero : β_fun (x, y) = 0 := by
            by_contra hβne
            obtain ⟨hMem, hEval⟩ := hβsup (x, y) hβne
            obtain ⟨k, hk⟩ := zerosAt_covers_zeros E msg.toD (x, y) hMem hEval
            -- distinctR (σ k) = (x, y).
            have hDRσ : distinctR E stmt msg hkm (σ k) = (x, y) := by
              rw [← hσ_eq k, hk]
            -- Case on σ k: either 0 or baseImagePos.
            rcases fin_one_plus_cases (baseImageCount E stmt msg hkm) (σ k)
              with hσ_zero | ⟨i, hσ_succ⟩
            · -- σ k = 0 ⇒ (x, y) = distinctR 0 = -P_aff, contradicts hxy.
              rw [hσ_zero, distinctR_zero] at hDRσ
              exact hxy hDRσ.symm
            · -- σ k = ⟨i+1, _⟩ ⇒ (x, y) = baseAt i ∈ baseImage.
              rw [hσ_succ, distinctR_succ] at hDRσ
              exact hInImage (hDRσ ▸ baseAt_mem_baseImage E stmt msg hkm i)
          rw [hβ_eq_zero]
          rfl

/-- **S6 + S4 + S5 combined.** Under the full T4 hypothesis set,
    the extractor succeeds and its divisor coefficient function
    is principal. -/
theorem extractor_succeeds_and_isPrincipal
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hDeg : msg.toD.degE ≤ d) (hd : d < E.q) (hkm : stmt.k = msg.k)
    (hAdm : stmt.admSet (msg.polyA, msg.polyB))
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ →
      logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
        (fun i => msg.m (hkm ▸ i)) A₀ A₁ = 0)
    (hPolyGZero :
      ∀ (β_fun : ZMod E.q × ZMod E.q → ℕ),
        (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0) →
        (∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) →
        ((∑ P ∈ E.points, β_fun P) = msg.toD.degE) →
        ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
          A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
          polyG E (zerosAt E msg.toD)
            (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
            (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
            A₀ A₁ = 0)
    (hValidPairsLarge :
      6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) + 1
        ≤ (validPairs E).card) :
    extractorSucceeds E stmt msg d hkm ∧
    IsPrincipal E (extractorDivisorCoeffs E stmt msg hkm) := by
  classical
  -- Step 1: apply S4.
  obtain ⟨β_fun, σ, hβsup, hβcov, hβsum, hdCoeffsPrincipal,
          hσ_eq, hσ_betam, hσ_off⟩ :=
    distinctSigma_exists E stmt msg d hDeg hd hkm hAdm hNoNegP
      hAllZero hPolyGZero hValidPairsLarge
  -- Step 2: apply S5 to get extractorSucceeds + scalar identification.
  obtain ⟨hBound, hCanon, hNonCanon⟩ :=
    extractorCoeffFromSigma_satisfies_D3 E stmt msg d hDeg hkm hNoNegP
      β_fun hβsup hβcov hβsum σ hσ_eq hσ_betam hσ_off
  obtain ⟨hSucceeds, _hScalars_eq⟩ :=
    extractorSucceeds_of_natural_witness E stmt msg d hd hkm hNoNegP
      (extractorCoeffFromSigma E stmt msg hkm β_fun σ)
      hBound hCanon hNonCanon
  -- Step 3: pointwise matching ⇒ functional equality.
  have hEq : extractorDivisorCoeffs E stmt msg hkm =
             dCoeffs E msg.toD β_fun := by
    funext P
    exact extractorDivisorCoeffs_eq_dCoeffs E stmt msg d hDeg hd hkm
      hNoNegP β_fun hβsup hβcov hβsum σ hσ_eq hσ_betam hσ_off P
  -- Step 4: transfer IsPrincipal.
  refine ⟨hSucceeds, ?_⟩
  rw [hEq]
  exact hdCoeffsPrincipal

/-! ## T4 theorem: the original bridge statement as a theorem -/

/-- **T4 bridge theorem.** Derived from the S4+S5+S6 assembly
    (`extractor_succeeds_and_isPrincipal`) combined with the
    D4+D5 infrastructure (`target_eq_weightedSum_of_principal`).

    Conclusion: `extractorSucceeds` and
    `target = Σ [extractedScalars i] · B_i`.

    Requires the quantitative hypothesis `hValidPairsLarge`
    threaded from the T5 application inside the proof. -/
theorem extractorSucceeds_of_logDerivCheck_identically_zero_general
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hDeg : msg.toD.degE ≤ d) (hd : d < E.q) (hkm : stmt.k = msg.k)
    (hAdm : stmt.admSet (msg.polyA, msg.polyB))
    (hNoNegP : ¬ (negPIndexSet E stmt msg hkm).Nonempty)
    (hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ →
      logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
        (fun i => msg.m (hkm ▸ i)) A₀ A₁ = 0)
    (hPolyGZero :
      ∀ (β_fun : ZMod E.q × ZMod E.q → ℕ),
        (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0) →
        (∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) →
        ((∑ P ∈ E.points, β_fun P) = msg.toD.degE) →
        ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
          A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
          polyG E (zerosAt E msg.toD)
            (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
            (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
            A₀ A₁ = 0)
    (hValidPairsLarge :
      6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) + 1
        ≤ (validPairs E).card) :
    extractorSucceeds E stmt msg d hkm ∧
    ECPoint.affine stmt.target.1 stmt.target.2 =
      ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
        (fun i => ECPoint.zsmul E
                   (extractedScalars E stmt msg hkm i)
                   (ECPoint.affine (extractorBases E stmt msg hkm i).1
                                   (extractorBases E stmt msg hkm i).2)) := by
  obtain ⟨hSucc, hPrincipal⟩ :=
    extractor_succeeds_and_isPrincipal E stmt msg d hDeg hd hkm hAdm hNoNegP
      hAllZero hPolyGZero hValidPairsLarge
  exact ⟨hSucc,
    target_eq_weightedSum_of_principal E stmt msg hkm hNoNegP hPrincipal⟩

/-! ## Extractor validity (both cases) -/

/-- **Extractor validity (both cases).** The extracted witness
    satisfies the dlog relation `dlogHolds`:
    * Special case (`-P ∈ {B_j}`): `extracted_scalars_valid_special`.
    * General case (`-P ∉ {B_j}`): T4 theorem's second conjunct. -/
theorem extracted_scalars_valid
    (stmt : DlogStatement E.q) (msg : MAProverMsg E.q) (d : ℕ)
    (hDeg : msg.toD.degE ≤ d) (hd : d < E.q) (hkm : stmt.k = msg.k)
    (hAdm : stmt.admSet (msg.polyA, msg.polyB))
    (hAllZero : ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
      A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
      logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ →
      logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
        (fun i => msg.m (hkm ▸ i)) A₀ A₁ = 0)
    (hPolyGZero :
      ∀ (β_fun : ZMod E.q × ZMod E.q → ℕ),
        (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0) →
        (∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) →
        ((∑ P ∈ E.points, β_fun P) = msg.toD.degE) →
        ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
          A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
          polyG E (zerosAt E msg.toD)
            (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
            (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
            A₀ A₁ = 0)
    (hValidPairsLarge :
      6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) + 1
        ≤ (validPairs E).card) :
    ECPoint.affine stmt.target.1 stmt.target.2 =
      ECPoint.weightedSum E (Finset.univ : Finset (Fin msg.k))
        (fun i => ECPoint.zsmul E
                   (extractedScalars E stmt msg hkm i)
                   (ECPoint.affine (extractorBases E stmt msg hkm i).1
                                   (extractorBases E stmt msg hkm i).2)) := by
  classical
  by_cases hNegP : (negPIndexSet E stmt msg hkm).Nonempty
  · exact extracted_scalars_valid_special E stmt msg hkm hNegP
  · exact (extractorSucceeds_of_logDerivCheck_identically_zero_general
            E stmt msg d hDeg hd hkm hAdm hNegP hAllZero hPolyGZero
            hValidPairsLarge).2

/-! ## Theorem 6: Extractable MA protocol -/

/-- **Theorem 6 (MA extractability) — upgraded form with valid witness.**

    Knowledge soundness of the MA protocol. For every first-round message,
    one of the two branches holds:

    * **Witness branch**: there exists a witness `wit` satisfying the
      dlog relation `dlogHolds E stmt wit hkm` such that the extractor
      returns `some wit`; or

    * **Bound branch**: the set of accepting challenges in `validPairs`
      has cardinality at most
      `(72 · (d + stmt.k + 6) + 4) · |E.points|
        + 6 · q · ((d + k + 1) + (d + k + 1) · (d + k))`.

    The second summand in the bound handles the "small `|validPairs|`"
    regime where the T5 quantitative criterion cannot be invoked. -/
theorem ma_extractable
    (stmt : DlogStatement E.q) (d : ℕ) (hd : d < E.q) (hd2 : 2 ≤ d)
    (msg : MAProverMsg E.q) (hDeg : msg.toD.degE ≤ d)
    (hkm : stmt.k = msg.k)
    (hPolyGZero :
      ∀ (β_fun : ZMod E.q × ZMod E.q → ℕ),
        (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg.toD.eval P.1 P.2 = 0) →
        (∀ P ∈ E.points, msg.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) →
        ((∑ P ∈ E.points, β_fun P) = msg.toD.degE) →
        ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
          A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
          polyG E (zerosAt E msg.toD)
            (fun k => ((multAt E β_fun msg.toD k : ℕ) : ZMod E.q))
            (distinctR E stmt msg hkm) (distinctM' E stmt msg hkm)
            A₀ A₁ = 0) :
    (∃ wit : DlogWitness E.q,
        maExtractor E stmt msg d hd hkm = some wit
        ∧ dlogHolds E stmt wit) ∨
    ((validPairs E).filter
        (fun p => maVerifierAccepts E stmt msg ⟨p.1, p.2⟩ hkm)).card
      ≤ (72 * (d + stmt.k + 6) + 4) * E.points.card
        + 6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) := by
  classical
  by_cases hNV : ∃ A₀ A₁, A₀ ∈ E.points ∧ A₁ ∈ E.points ∧ A₀.1 ≠ A₁.1 ∧
     logDerivCheckFnDefined E msg.toD stmt.target stmt.bases A₀ A₁ ∧
     logDerivCheckFn E msg.toD stmt.target stmt.k stmt.bases
       (fun i => msg.m (hkm ▸ i)) A₀ A₁ ≠ 0
  · -- Nonvanishing on defined subset: `log_deriv_sz` bounds the NotEq bad set.
    right
    set acceptSet : Finset ((ZMod E.q × ZMod E.q) × (ZMod E.q × ZMod E.q)) :=
      (validPairs E).filter
        (fun p => maVerifierAccepts E stmt msg ⟨p.1, p.2⟩ hkm) with hAS
    set badSet : Finset ((ZMod E.q × ZMod E.q) × (ZMod E.q × ZMod E.q)) :=
      badChallengesNotEq E msg.toD stmt.target stmt.bases
        (fun i => msg.m (hkm ▸ i)) with hBS
    have hSub : acceptSet ⊆ badSet := by
      intro p hp
      simp only [hAS, Finset.mem_filter] at hp
      simp only [hBS, badChallengesNotEq, Finset.mem_filter]
      exact ⟨hp.1, hp.2.2.2⟩
    have hCardLe : acceptSet.card ≤ badSet.card := Finset.card_le_card hSub
    have hDegLt : msg.toD.degE < E.q := lt_of_le_of_lt hDeg hd
    have hBound :=
      log_deriv_sz E msg.toD stmt.target stmt.bases
        (fun i => msg.m (hkm ▸ i)) hDegLt hNV
    have hMono : (72 * (msg.toD.degE + stmt.k + 6) + 4) * E.points.card
                 ≤ (72 * (d + stmt.k + 6) + 4) * E.points.card := by
      apply Nat.mul_le_mul_right
      have : msg.toD.degE + stmt.k + 6 ≤ d + stmt.k + 6 := by
        exact Nat.add_le_add_right (Nat.add_le_add_right hDeg _) _
      omega
    exact le_trans hCardLe (le_trans hBound
      (le_trans hMono (Nat.le_add_right _ _)))
  · push_neg at hNV
    by_cases hAdm : stmt.admSet (msg.polyA, msg.polyB)
    · classical
      by_cases hNegP : (negPIndexSet E stmt msg hkm).Nonempty
      · left
        have hSucc : extractorSucceeds E stmt msg d hkm :=
          extractorSucceeds_special E stmt msg d hkm hNegP hd2
        have hRelation := extracted_scalars_valid_special E stmt msg hkm hNegP
        let wit : DlogWitness E.q :=
          ⟨msg.k, extractedScalars E stmt msg hkm, d, hSucc⟩
        refine ⟨wit, ?_, ?_⟩
        · show (if h : extractorSucceeds E stmt msg d hkm
                then some (⟨msg.k, extractedScalars E stmt msg hkm, d, h⟩ : DlogWitness E.q)
                else none) = _
          rw [dif_pos hSucc]
        · refine ⟨hkm, ?_⟩
          show (ECPoint.affine stmt.target.1 stmt.target.2 : ECPoint E.q) =
            ECPoint.weightedSum E (Finset.univ : Finset (Fin wit.k))
              (fun i => ECPoint.zsmul E (wit.scalars i)
                (ECPoint.affine
                  (stmt.bases (Fin.cast hkm.symm i)).1
                  (stmt.bases (Fin.cast hkm.symm i)).2))
          convert hRelation using 1
      · by_cases hL :
            6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) + 1
              ≤ (validPairs E).card
        · left
          obtain ⟨hSucc, hRelation⟩ :=
            extractorSucceeds_of_logDerivCheck_identically_zero_general E stmt msg d
              hDeg hd hkm hAdm hNegP
              (fun A₀ A₁ hA₀ hA₁ hDef => hNV A₀ A₁ hA₀ hA₁ hDef)
              hPolyGZero hL
          let wit : DlogWitness E.q :=
            ⟨msg.k, extractedScalars E stmt msg hkm, d, hSucc⟩
          refine ⟨wit, ?_, ?_⟩
          · show (if h : extractorSucceeds E stmt msg d hkm
                  then some (⟨msg.k, extractedScalars E stmt msg hkm, d, h⟩ : DlogWitness E.q)
                  else none) = _
            rw [dif_pos hSucc]
          · refine ⟨hkm, ?_⟩
            show (ECPoint.affine stmt.target.1 stmt.target.2 : ECPoint E.q) =
              ECPoint.weightedSum E (Finset.univ : Finset (Fin wit.k))
                (fun i => ECPoint.zsmul E (wit.scalars i)
                  (ECPoint.affine
                    (stmt.bases (Fin.cast hkm.symm i)).1
                    (stmt.bases (Fin.cast hkm.symm i)).2))
            convert hRelation using 1
        · -- Small-validPairs regime: bound directly by `|validPairs| < threshold`.
          right
          push_neg at hL
          set acceptSet : Finset ((ZMod E.q × ZMod E.q) × (ZMod E.q × ZMod E.q)) :=
            (validPairs E).filter
              (fun p => maVerifierAccepts E stmt msg ⟨p.1, p.2⟩ hkm) with hAS
          have hSubVP : acceptSet ⊆ validPairs E := by
            intro p hp
            simp only [hAS, Finset.mem_filter] at hp
            exact hp.1
          have hCardLe : acceptSet.card ≤ (validPairs E).card :=
            Finset.card_le_card hSubVP
          have hVP : (validPairs E).card
              ≤ 6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)) :=
            Nat.lt_succ_iff.mp hL
          exact le_trans hCardLe (le_trans hVP (Nat.le_add_left _ _))
    · right
      set acceptSet : Finset ((ZMod E.q × ZMod E.q) × (ZMod E.q × ZMod E.q)) :=
        (validPairs E).filter
          (fun p => maVerifierAccepts E stmt msg ⟨p.1, p.2⟩ hkm) with hAS
      have hEmpty : acceptSet = ∅ := by
        apply Finset.eq_empty_of_forall_notMem
        intro p hp
        simp only [hAS, Finset.mem_filter] at hp
        exact hAdm hp.2.2.1
      rw [hEmpty]
      simp

/-! ## Theorem 7: Knowledge-Sound IP -/

/-- **Theorem 7 (IP knowledge soundness).**

    The IP has the same knowledge guarantee as the MA (extractor-or-
    small-accept-set disjunction), plus uniqueness of the third-round
    response (which makes the IP-to-MA reduction tight). -/
theorem ip_knowledge_sound
    (stmt : DlogStatement E.q) (d : ℕ) (hd : d < E.q) (hd2 : 2 ≤ d)
    (msg1 : MAProverMsg E.q) (hDeg : msg1.toD.degE ≤ d)
    (hkm : stmt.k = msg1.k)
    (hPolyGZero :
      ∀ (β_fun : ZMod E.q × ZMod E.q → ℕ),
        (∀ P, β_fun P ≠ 0 → P ∈ E.points ∧ msg1.toD.eval P.1 P.2 = 0) →
        (∀ P ∈ E.points, msg1.toD.eval P.1 P.2 = 0 → β_fun P ≠ 0) →
        ((∑ P ∈ E.points, β_fun P) = msg1.toD.degE) →
        ∀ A₀ A₁ : ZMod E.q × ZMod E.q,
          A₀ ∈ E.points → A₁ ∈ E.points → A₀.1 ≠ A₁.1 →
          polyG E (zerosAt E msg1.toD)
            (fun k => ((multAt E β_fun msg1.toD k : ℕ) : ZMod E.q))
            (distinctR E stmt msg1 hkm) (distinctM' E stmt msg1 hkm)
            A₀ A₁ = 0) :
    ((∃ wit : DlogWitness E.q,
         maExtractor E stmt msg1 d hd hkm = some wit
         ∧ dlogHolds E stmt wit) ∨
     ((validPairs E).filter
        (fun p => maVerifierAccepts E stmt msg1 ⟨p.1, p.2⟩ hkm)).card
      ≤ (72 * (d + stmt.k + 6) + 4) * E.points.card
        + 6 * E.q * ((d + stmt.k + 1) + (d + stmt.k + 1) * (d + stmt.k)))
    ∧ ∀ (chal : MAChallenge E.q) (A₂ : ZMod E.q × ZMod E.q)
        (msg3 msg3' : IPProverMsg3 E.q),
        msg1.toD.eval chal.A₀.1 chal.A₀.2 ≠ 0 →
        msg1.toD.eval chal.A₁.1 chal.A₁.2 ≠ 0 →
        msg1.toD.eval A₂.1 A₂.2 ≠ 0 →
        (lineThrough chal.A₀.1 chal.A₀.2 chal.A₁.1 chal.A₁.2).eval
            stmt.target.1 (-stmt.target.2) ≠ 0 →
        ipVerifierAccepts E stmt msg1 chal A₂ msg3 →
        ipVerifierAccepts E stmt msg1 chal A₂ msg3' →
        msg3 = msg3' := by
  refine ⟨?_, ?_⟩
  · exact ma_extractable E stmt d hd hd2 msg1 hDeg hkm hPolyGZero
  · intro chal A₂ msg3 msg3' hD₀ hD₁ hD₂ hLP hAcc hAcc'
    exact ip_unique_third_round E stmt msg1 chal A₂ msg3 msg3'
            hD₀ hD₁ hD₂ hLP hAcc hAcc'

end Divisor
