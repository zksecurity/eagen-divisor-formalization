/-
  Divisor/ChordLogDerivProof.lean

  Proof of `chordLogDerivMatchesNormZ` — the scalar log-derivative match
  at a chord (Phase 4 content).

  ## Important discovery: splitting hypothesis required

  The identity `chordLogDerivMatchesNormZ` is **false** when `normPoly E D`
  does not split over `F_q`. Counterexample:

  * `E : y² = x³ + 1` over `F_7` (curve `A = 0, B = 1`).
  * `D = x² + 1` (i.e., `D.a = X² + 1`, `D.b = 0`).
  * `A₀ = (0, 1)`, `A₁ = (1, 3)`.
  * `λ = 2`, `μ = 1`, third chord point `A₂ = (3, 0)`.
  * `logDerivTerm` at `(0,1)` = 0, at `(1,3)` = 4, at `(3,0)` = 0.
  * `normPoly = (x²+1)²` has no roots in `F_7` (since `-1` is not a QR).
  * `zerosFinset = ∅`, so `normZ = 1` (constant) and `normZ' = 0`.
  * **LHS** = `(0 + 4 + 0) * 1 = 4 ≠ 0` = **RHS**.

  The issue is that `normZ` only tracks `F_q`-rational zeros of `D` on `E`.
  When `normPoly` does not split, some zeros lie over non-rational
  `x`-coordinates and `normZ` misses them.

  ## Note on `CoordRingElt.divisor_degree_eq`

  The axiom `CoordRingElt.divisor_degree_eq` in `BetaConstructive.lean`
  claims `∑ P ∈ E.points, betaConstructive E D P = D.degE` for all
  nonzero `D`. This is false when `normPoly E D` does not split over
  `F_q` (the same counterexample above gives ∑β = 0 ≠ 4 = D.degE).
  The correct statement requires either:
  (a) summing over ALL algebraic points (not just `F_q`-rational ones), or
  (b) adding `normPoly_splits_over_Fq E D` as a hypothesis.

  ## Proof strategy

  Under the hypothesis `hTraceLogDeriv` (the function-field
  trace-of-log-derivative identity), the proof reduces to combining with
  `normZ_logDeriv_at_chord_intercept`.

  The trace-of-log-derivative identity states:

      Σᵢ logDerivTerm(Aᵢ, λ) = − Σ_{Q ∈ zerosFinset} β(Q) / L(Q)

  This identity follows from the function-field norm computation:
  the product `∏ D(Aᵢ(z))` viewed as a polynomial in `z` is proportional
  to `normZ(z)` under the splitting hypothesis. Differentiating and
  evaluating at `z = μ` yields the trace identity.

  A complete formalization would require resultant theory (or the
  theory of norms in the degree-3 extension `F_q(E) / F_q(z)`) which
  is not currently available in Mathlib. The hypothesis `hTraceLogDeriv`
  encapsulates this function-field content.
-/
import Divisor.Lemma6
import Divisor.NormZDecomp
import Divisor.ResidueIdentity

open Polynomial Finset

namespace Divisor

variable (E : ECSetup)

/-- **`chordLogDerivMatchesNormZ` holds** under the trace-of-log-derivative
    identity from function-field theory.

    The hypothesis `hTraceLogDeriv` is the function-field content: the sum
    of log-derivative terms at the three chord intersection points equals
    the negative partial-fraction sum over `zerosFinset E D`. This follows
    from the proportionality `∏ D(Aᵢ(z)) = C · normZ(z)` (the
    function-field norm identity) by differentiation and evaluation at
    `z = μ`, which requires resultant theory not yet in Mathlib.

    Given `hTraceLogDeriv`, the proof combines it with the PFE identity
    `normZ_logDeriv_at_chord_intercept` (which expresses `normZ'(μ)` as
    `−normZ(μ) · Σ β/L`) and cancels `normZ(μ) ≠ 0`. -/
theorem chordLogDerivMatchesNormZ_holds
    (E : ECSetup) (D : CoordRingElt E.q)
    (A₀ A₁ : ZMod E.q × ZMod E.q)
    -- Non-degeneracy hypotheses
    (hQline : ∀ Q ∈ zerosFinset E D,
      (lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval Q.1 Q.2 ≠ 0)
    (_hNormZne : (normZ E (slopeOf A₀.1 A₀.2 A₁.1 A₁.2) D).eval
      (zLambda E (slopeOf A₀.1 A₀.2 A₁.1 A₁.2) A₀) ≠ 0)
    -- Function-field content: trace-of-log-derivative identity
    (hTraceLogDeriv :
      logDerivTerm E D E.curveA (slopeOf A₀.1 A₀.2 A₁.1 A₁.2) A₀
        + logDerivTerm E D E.curveA (slopeOf A₀.1 A₀.2 A₁.1 A₁.2) A₁
        + logDerivTerm E D E.curveA (slopeOf A₀.1 A₀.2 A₁.1 A₁.2)
            ((slopeOf A₀.1 A₀.2 A₁.1 A₁.2) ^ 2 - A₀.1 - A₁.1,
             (slopeOf A₀.1 A₀.2 A₁.1 A₁.2) *
               ((slopeOf A₀.1 A₀.2 A₁.1 A₁.2) ^ 2 - A₀.1 - A₁.1)
               + (A₀.2 - (slopeOf A₀.1 A₀.2 A₁.1 A₁.2) * A₀.1))
      = -∑ Q ∈ zerosFinset E D,
          (betaConstructive E D Q : ZMod E.q) *
            ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval Q.1 Q.2)⁻¹) :
    chordLogDerivMatchesNormZ E D A₀ A₁ := by
  -- Unfold the definition
  unfold chordLogDerivMatchesNormZ
  -- Abbreviations
  set lam := slopeOf A₀.1 A₀.2 A₁.1 A₁.2
  set μ := zLambda E lam A₀
  set LT := logDerivTerm E D E.curveA lam A₀
    + logDerivTerm E D E.curveA lam A₁
    + logDerivTerm E D E.curveA lam
        (lam ^ 2 - A₀.1 - A₁.1,
         lam * (lam ^ 2 - A₀.1 - A₁.1) + (A₀.2 - lam * A₀.1))
  set N := (normZ E lam D).eval μ
  set Nd := eval μ (derivative (normZ E lam D))
  set S := ∑ Q ∈ zerosFinset E D,
    (betaConstructive E D Q : ZMod E.q) *
      ((lineThrough A₀.1 A₀.2 A₁.1 A₁.2).eval Q.1 Q.2)⁻¹
  -- From normZ_logDeriv_at_chord_intercept: Nd = -(N * S)
  have hPFE : Nd = -(N * S) := by
    exact normZ_logDeriv_at_chord_intercept E D A₀ A₁ hQline
  -- From hTraceLogDeriv: LT = -S
  have hLT : LT = -S := hTraceLogDeriv
  -- Goal: LT * N = Nd
  show LT * N = Nd
  rw [hPFE, hLT]
  ring

end Divisor
